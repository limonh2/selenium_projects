package com.fasttrack.pages;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Loginpage extends BaseInitialization {

	// Login fields

	@FindBy(id = "Username")
	private WebElement userName;

	@FindBy(id = "email")
	private WebElement userNameguru;
	
	@FindBy(id = "passwd")
	public WebElement userPasswordguru;

	
	@FindBy(id = "SubmitLogin")
	public WebElement loginBtnguru;
	
	
	
	@FindBy(id = "Password")
	public WebElement userPassword;

	@FindBy(xpath = "//*[@id=\"login\"]/div/div[2]/div/form/div[4]/div/button")
	public WebElement loginBtn;

	@FindBy(xpath = "//*[@id=\"content\"]/div/div/div/div/div/div/div/div[1]/h3/text()[1]")
	private WebElement welcomeText;

	@FindBy(xpath = "//h3[normalize-space()='Successfully Logged in...']")
	public WebElement welcomeMessage;
	
	@FindBy(xpath = "//a[normalize-space()='Selenium']//b[@class='caret']")
	public WebElement seleniumMenu;
	
	

	public Loginpage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	@SuppressWarnings("resource")
	public void userLogin2(String sUserName2) throws Exception {

		Thread.sleep(2000);
		elementControl.setText(userName, sUserName2);
		
		 elementControl.clickElement(userPassword);

		
		
		 Scanner userPassword2 = new Scanner(System.in);  // Create a Scanner object
		System.out.println("Enter password");
		 userPassword2.next();
		 
		 
		 elementControl.clickElement(loginBtn);
		 
	}
	
	
	  public void userLogin(String sUserName, String sUserPassword) throws Exception {
	

		Thread.sleep(2000);
		elementControl.setText(userNameguru, sUserName);

		elementControl.setText(userPasswordguru, sUserPassword);

		elementControl.clickElement(loginBtnguru);
	}


	public String getWelcomeText() throws Exception {
		return elementControl.getText(welcomeText);
	}

}
