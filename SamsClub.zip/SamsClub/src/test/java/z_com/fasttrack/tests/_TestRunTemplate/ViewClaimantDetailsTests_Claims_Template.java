package z_com.fasttrack.tests._TestRunTemplate;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.VCM;
import com.fasttrack.pages.WorkloadReportpage;

import commonLibs.contracts.IDropdown;
import commonLibs.implementation.ElementControl;

@SuppressWarnings("unused")
public class ViewClaimantDetailsTests_Claims_Template extends TestSetup {

	@Test(priority = 0)

	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC00 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//													"Claims" Test Cases	

	@Test(priority = 1)
	public void Claims_01() throws Exception {
		/*
		 * Pre-reqs: LTD
		 * 
		 */
		extentTest = extent.createTest("Claims_01_LTD Gateway");

		dashboardpage.claimaintQuickSearch("258149"); // 257622

		Thread.sleep(2000);
		dashboardpage.DashboardTab.click();

		Thread.sleep(2000);
	}
}
