package z_com.fasttrack.tests._TestRunTemplate;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.AddClaimantpage;

public class AddClaimantTests_Template extends TestSetup {

	@Test(priority = 0)
	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC1 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

	/*	@Test(enabled=false) 
	public void createnewClaimant() throws Exception {

		extentTest = extent.createTest("TC2 - Verify you can create a claimant");
						
		addClaimantpage.selectLWProduct();
		extentTest.log(Status.INFO, "Product LW selected");

		extentTest.log(Status.INFO, "Owner is being created");
		addClaimantpage.createOwner("Justin513", "Timberlake513", "1 Paterson Ave", "Nutley", "NJ", "07100");

		extentTest.log(Status.INFO, "Owner is created");

		//dashboardpage.enterpolicyNumber("LW10001");
		//extentTest.log(Status.INFO, "Policy # entered");

		

		dashboardpage.createnewClaimant("Justin513", "Timberlake513", "1 Paterson Ave", "Paterson", "NJ", "07501",
				"01/01/1999", "05/01/2020", "05/06/2021", "c");
		extentTest.log(Status.INFO, "Claimant created");

		Thread.sleep(10000);

	
		
	}
	*/
	/*@Test (enabled=false) //(priority = 1)
	public void EditClaimant_01_02() throws Exception {

		extentTest = extent.createTest("EditClaimant_01_FastTrack proper_ Change disability type_Core");
		dashboardpage.claimaintQuickSearch("68026");
		addClaimantpage.EditClaimantBtn.click();
		addClaimantpage.SelectDisabilityType("Physical");
		extentTest.log(Status.INFO, "Select option is Physical");
		addClaimantpage.EditClaimantSaveBtn.click();
		addClaimantpage.BreadCrumbLinkToViewClaimantPageBtn.click();
		extentTest.log(Status.INFO, "Clicks Save button and Clicks BreadCrumb link to ViewClaimant page");
		addClaimantpage.FullDetailsBtn.click();
		extentTest.log(Status.INFO, "Clicks on Full Detail button");
		addClaimantpage.VerifyDisabilityTypeisPhysical();
		Thread.sleep(2000);
		extentTest.log(Status.INFO, "Verify option is Physical");
		Thread.sleep(2000);
		addClaimantpage.CloseXButton.click();
		extentTest.log(Status.INFO, "X out of the popup");
		dashboardpage.DashboardTab.click();
		Thread.sleep(2000);
	
		
	}
	*/
	@Test (priority = 1)
	/*
	 * Pre-reqs: LTD claim
	 * 
	 * 
	 */
	public void EditClaimant_01_and_02() throws Exception {

		extentTest = extent.createTest("EditClaimant_01_and 02_FastTrack Proper_ Change Disablity Type and Claimant Address_ Core");
		dashboardpage.claimaintQuickSearch("68026");
		addClaimantpage.EditClaimantBtn.click();
		
		addClaimantpage.SelectDisabilityType("Physical");
		extentTest.log(Status.INFO, " Physical option was selected");
		
		addClaimantpage.address.clear();
		addClaimantpage.address.sendKeys("100 Main Street");
		
		addClaimantpage.city.clear();
		addClaimantpage.city.sendKeys("Nutley");
		
		Thread.sleep(2000);
		
		addClaimantpage.SelectStatefromDropdown("NJ");
		
		addClaimantpage.zipCode.clear();
		addClaimantpage.zipCode.sendKeys("07110");
		
		extentTest.log(Status.INFO, "Enters new address for claimant");
		
		addClaimantpage.EditClaimantSaveBtn.click();
		addClaimantpage.BreadCrumbLinkToViewClaimantPageBtn.click();
		extentTest.log(Status.INFO, "Clicks Save button and Clicks BreadCrumb link to ViewClaimant page");
		addClaimantpage.FullDetailsBtn.click();
		extentTest.log(Status.INFO, "Clicks on Full Detail button");
		
		addClaimantpage.VerifyDisabilityTypeisPhysical();
		Thread.sleep(2000);
		extentTest.log(Status.INFO, "Verify option selected is Physical");
		
		addClaimantpage.VerifyAddress1("100 Main Street", "100 Main Street");
		addClaimantpage.VerifyCity("Nutley", "Nutley");
		addClaimantpage.VerifyState("NJ", "NJ");
		addClaimantpage.VerifyState("07110", "07110");
		Thread.sleep(2000);
		
		extentTest.log(Status.INFO, "Verifies updated Address, City, State, Zipcode ");
		Thread.sleep(2000);
		addClaimantpage.CloseXButton.click();
		extentTest.log(Status.INFO, "X out of the popup");
		dashboardpage.DashboardTab.click();
		Thread.sleep(2000);
	
		
	}
	
	@Test(priority = 2)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void EditClaimant_03_04() throws Exception {

		extentTest = extent.createTest("EditClaimant_03_and_04 FastTrack Proper_ Edit Predisability Earnings and Epic Claim ID_LWOP");
		dashboardpage.claimaintQuickSearch("77806");
		addClaimantpage.EditClaimantBtn.click();
		
		addClaimantpage.LW_PredisabilityEarnings.clear();
		addClaimantpage.LW_PredisabilityEarnings.sendKeys("25000");
		
		addClaimantpage.LW_EpicClaimId.clear();
		addClaimantpage.LW_EpicClaimId.sendKeys("A12345");
		Thread.sleep(2000);
		
		
		extentTest.log(Status.INFO, "Enters new earnings amount and epic id");
		
		addClaimantpage.EditClaimantSaveBtn.click();
		addClaimantpage.BreadCrumbLinkToViewClaimantPageBtn.click();
		extentTest.log(Status.INFO, "Clicks Save button and Clicks BreadCrumb link to ViewClaimant page");
		addClaimantpage.FullDetailsBtn.click();
		extentTest.log(Status.INFO, "Clicks on Full Detail button");
		
		addClaimantpage.VerifyPredisabilityEarnings("25,000", "25,000");
		addClaimantpage.VerifyEpicClaimId("A12345", "A12345");
		
		
		Thread.sleep(2000);
		
		extentTest.log(Status.INFO, "Verifies updated PreDis Earnings and Epic Claim ID ");
		Thread.sleep(2000);
		addClaimantpage.CloseXButton.click();
		extentTest.log(Status.INFO, "X out of the popup");
		dashboardpage.DashboardTab.click();
		Thread.sleep(2000);
	
		
	}
	
}
