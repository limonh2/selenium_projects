package com.fasttrackRTW.pages;

import org.openqa.selenium.WebDriver;

public class Hotelspage extends BaseInitialization{

	public Hotelspage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	

}
