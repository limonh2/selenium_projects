package com.fasttrackRTW.pages;

import org.openqa.selenium.WebDriver;

public class Holidayspage extends BaseInitialization{

	public Holidayspage(WebDriver driver) {
		super(driver);
		
	}

}
