package com.fasttrackRTW.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Dashboardpage extends BaseInitialization {

	@FindBy(linkText = "Add New Claimant")
	public WebElement addnewClaimant;

	// Owner

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multClContactCtrl_txtFirstNameNew")
	public WebElement OfirstName;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multClContactCtrl_txtLastNameNew")
	public WebElement OlastName;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multClContactCtrl_txtAddress1New")
	public WebElement Oaddress;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multClContactCtrl_txtCityNew")
	public WebElement Ocity;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multClContactCtrl_inputStateNew_ddlState")
	public WebElement Ostate;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multClContactCtrl_txtZipNew")
	public WebElement OzipCode;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multClContactCtrl_btnAddNewContact")
	public WebElement commitownerBtn;

	// Policy number and Carrier Product LW or DI (LTD)
	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multiplePolicyControlWithCarrierProduct1_txtNewPolicyNumber")
	public WebElement policyNumber;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multiplePolicyControlWithCarrierProduct1_cbNewLW")
	public WebElement productLW;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multiplePolicyControlWithCarrierProduct1_cbNewDI")
	public WebElement productDI_LTD;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_multiplePolicyControlWithCarrierProduct1_btnAdd")
	public WebElement addBtn;

	@FindBy(id = "btnClear")
	public WebElement clearBtn;

	// claimant details

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtFirst")
	public WebElement firstName;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtLast")
	public WebElement lastName;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtAddress1")
	public WebElement address;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtCity")
	public WebElement city;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_claimantState_ddlState")
	public WebElement state;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtZip")
	public WebElement zipCode;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtDateOfBirth")
	public WebElement dateofBirth;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtDateClaimReceived")
	public WebElement dateclaimReceived;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_txtMaxBenefitDate")
	public WebElement maxbenefitDate;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_ClaimantControl_ddlInsuranceAgencyCompany")
	public WebElement insuranceAgency;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_btnSave")
	public WebElement saveBtn;

	@FindBy(xpath = "//*[@id=\"aspnetForm\"]/div[3]/div/div/div/div/div/div[1]/p[1]")
	public WebElement successMessage;
	
	@FindBy(linkText = "Go to Claimant Details")
	public WebElement gotoclaimantDetailsBtn;
	
	
	
	public Dashboardpage(WebDriver driver) {

		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void creatOwner(String OOfirstName, String OOlastName, String OOaddress, String OOcity, String OOstate,
			String OOzipCode) throws Exception {
		elementControl.clickElement(addnewClaimant);
		elementControl.setText(OfirstName, OOfirstName);
		elementControl.setText(OlastName, OOlastName);
		elementControl.setText(Oaddress, OOaddress);
		elementControl.setText(Ocity, OOcity);
		elementControl.setText(Ostate, OOstate);
		elementControl.setText(OzipCode, OOzipCode);
		elementControl.clickElement(commitownerBtn);
		Thread.sleep(5000);
	}

	public void enterpolicyNumber(String ppolicyNumber) throws Exception {
		elementControl.setText(policyNumber, ppolicyNumber);

	}

	public void selectLWProduct() throws Exception {
		elementControl.clickElement(productLW);
		elementControl.clickElement(addBtn);
		Thread.sleep(5000);

	}

	public void selectProductDI_LTD() throws Exception {
		elementControl.clickElement(productDI_LTD);
		elementControl.clickElement(addBtn);
		Thread.sleep(5000);

	}

	public void createnewClaimant(String sfirstName, String slastName, String saddress, String scity, String sstate,
			String szipCode, String ddateofBirth, String ddateclaimRecieved, String mmaxbenefitDate,
			String iinsuranceAgency) throws Exception {
		elementControl.setText(firstName, sfirstName);
		elementControl.setText(lastName, slastName);
		elementControl.setText(address, saddress);
		elementControl.setText(city, scity);
		elementControl.setText(state, sstate);
		elementControl.setText(zipCode, szipCode);
		Thread.sleep(5000);

		elementControl.clickElement(dateofBirth);
		elementControl.setText(dateofBirth, ddateofBirth);
		Thread.sleep(5000);
		elementControl.clickElement(dateclaimReceived);
		elementControl.setText(dateclaimReceived, ddateclaimRecieved);
		Thread.sleep(5000);
		elementControl.clickElement(maxbenefitDate);
		elementControl.setText(maxbenefitDate, mmaxbenefitDate);
		elementControl.clickElement(zipCode);

		elementControl.clickElement(insuranceAgency);
		elementControl.setText(insuranceAgency, iinsuranceAgency);
		elementControl.clickElement(zipCode);

		Thread.sleep(5000);

		elementControl.clickElement(saveBtn);
		Thread.sleep(5000);

		String expectedWelcomeText = "Claimant was successfully added!";
		String actualWelcomeText = elementControl.getText(successMessage);

		Assert.assertEquals(actualWelcomeText, expectedWelcomeText);
		//elementControl.clickElement(gotoclaimantDetailsBtn);
		//Thread.sleep(10000);
		
	}

}
