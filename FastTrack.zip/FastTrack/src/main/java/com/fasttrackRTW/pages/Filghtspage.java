package com.fasttrackRTW.pages;

import org.openqa.selenium.WebDriver;

public class Filghtspage extends BaseInitialization{

	public Filghtspage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
