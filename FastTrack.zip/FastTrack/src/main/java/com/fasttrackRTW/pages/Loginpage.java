package com.fasttrackRTW.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Loginpage extends BaseInitialization {

	// Login fields

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_login")
	private WebElement userName;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_password")
	private WebElement userPassword;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_submit")
	private WebElement loginBtn;

	@FindBy(xpath = "//*[@id=\"content\"]/div/div/div/div/div/div/div/div[1]/h3/text()[1]")
	private WebElement welcomeText;

	@FindBy(id = "ctl00_ctl00_MainContent_MainContent_lblUserFirstName")
	private WebElement welcomeuserName;

	public Loginpage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void userLogin(String sUserName, String sUserPassword) throws Exception {

		Thread.sleep(2000);
		elementControl.setText(userName, sUserName);

		elementControl.setText(userPassword, sUserPassword);

		elementControl.clickElement(loginBtn);
	}

	public String getWelcomeText() throws Exception {
		return elementControl.getText(welcomeText);
	}

}
