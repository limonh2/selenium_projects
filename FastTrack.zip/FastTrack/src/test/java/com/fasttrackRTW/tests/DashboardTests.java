package com.fasttrackRTW.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class DashboardTests extends TestSetup {

	@Test(priority = 0)
	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC1 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

	@Test(priority = 1)
	public void createnewClaimant() throws Exception {

		extentTest = extent.createTest("TC2 - Verify you can create a claimant");

		extentTest.log(Status.INFO, "Owner is being created");
		dashboardpage.creatOwner("Justin513", "Timberlake513", "1 Paterson Ave", "Paterson", "NJ", "07501");

		extentTest.log(Status.INFO, "Owner is created");

		dashboardpage.enterpolicyNumber("LW10001");
		extentTest.log(Status.INFO, "Policy # entered");

		dashboardpage.selectLWProduct();
		extentTest.log(Status.INFO, "Product LW selected");

		dashboardpage.createnewClaimant("Justin513", "Timberlake513", "1 Paterson Ave", "Paterson", "NJ", "07501",
				"01/01/1999", "05/01/2020", "05/06/2021", "c");
		extentTest.log(Status.INFO, "Claimant created");

		Thread.sleep(10000);

	}
}
