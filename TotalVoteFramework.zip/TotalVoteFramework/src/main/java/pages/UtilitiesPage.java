package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utils.Base;
import utils.DriverFactory;

import java.util.List;


public class UtilitiesPage extends Base {

    JavascriptExecutor js = ((JavascriptExecutor) DriverFactory.getDriver());

    public UtilitiesPage() {
        PageFactory.initElements(DriverFactory.getDriver(), this);
    }

    @FindBy(xpath = "//div[@style='display: block;']//select[@id='notice-template-select']")
    public WebElement drpNoticeName;

    @FindBy(xpath = "//input[@value=\"Save\"]")
    public WebElement saveBtnNotice;


    public void verifyValuePresentInDropDown(String noticeType) {
        nativeDropdownSelect(drpNoticeName, noticeType);
        Assert.assertTrue(isNativeDropdownSelected(drpNoticeName, noticeType));
    }

    public void clickSaveBtnNoticeMgmt() {
        saveBtnNotice.click();
        waitForSpinner();
    }
}



