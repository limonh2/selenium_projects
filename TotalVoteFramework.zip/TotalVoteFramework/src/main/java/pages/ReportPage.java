package pages;


import io.cucumber.datatable.DataTable;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.Base;
import utils.DriverFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;


public class ReportPage extends Base {

    JavascriptExecutor js = ((JavascriptExecutor) DriverFactory.getDriver());

    public static String RANDOM_TEXT;

    public ReportPage() {
        PageFactory.initElements(DriverFactory.getDriver(), this);
    }

    @FindBy(xpath = "//td[normalize-space()='Candidate Proofing']")
    public WebElement checkboxCandidateProofing;

    @FindBy(css = "input[placeholder=\"Enter a name for your report\"]")
    public WebElement reportName;

    @FindBy(xpath = "//label[text()='Description']/following-sibling::textarea")
    public WebElement reportDescription;

    @FindBy(xpath = "//h5[text()='Created Reports']//following-sibling::small[text()]")
    public WebElement reportBuilderReportsCount;


    public void userEntersReportName (String report){
        reportName.click();
        reportName.sendKeys(report);
    }

    public void userEntersReportDescription (String desc){
        reportDescription.click();
        reportDescription.sendKeys(desc);
    }


    public void clickOnReportRunButton() {
       By btnRun= By.xpath("//td[text()='"+RANDOM_TEXT+"']/following-sibling::td//button[contains(normalize-space(),'Run')]");
       driver.findElement(btnRun).click();
    }


}

