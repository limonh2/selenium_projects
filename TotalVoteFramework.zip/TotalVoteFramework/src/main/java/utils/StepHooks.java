package utils;



import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import io.cucumber.java.*;

public class StepHooks extends BaseStep {

    static boolean isLastScenarioPassed = true;

    public DataReader dataReader = new DataReader();
    public WebDriver driver = DriverFactory.getDriver();

    @After
    public void teardown(Scenario scenario){
//        if(scenario.isFailed()){
//            takeScreenShot(scenario);
//        }

       takeScreenShot(scenario);
    }
//    @BeforeTest
//    public void setup(Scenario scenario) throws Throwable {
        // Check if last scenario was passed, if so, then continue
//        Assumes.assumeThat("One of the last scenarios has failed", isLastScenarioPassed);


//        boolean isFirst = (driver == null);

//        if (isFirst) {
//            Driver.setupBrowser();
//            String startTimeStamp = BaseStep.startTimeStamp;
//            registerSchemaServiceTestResultsWriter();
//            setFeatureProperties();
//        }
//        BaseStep.scenario = scenario;
//        Base.scenario = scenario;
//        ImageComparator.scenario = scenario;
//        driver = Driver.openDriver(scenario);
//        initializePages(driver);

//        projectList = new ArrayList<>();
//        viewAsTextLines = new ArrayList<>();
//
//        resultName = "";
//        candidateName = "candidate" + Helper.getUniqueNumber();
//        electionName = "election" + Helper.getUniqueNumber();
//        projectName = "Project" + Helper.getUniqueNumber();
//
//        imageComparator = new ImageComparator(driver);
//    }

//    public void apiInit() throws InterruptedException {
//        if (url.contains(":4567")) {
//            initializeApiHandlers(backendUrl);
//        } else {
//            initializeApiHandlers(url);
//        }
//        login.loginRetry(userName, password);
//    }

//    private void registerSchemaServiceTestResultsWriter() throws Exception {
//        if (outputDir != null && !outputDir.isEmpty()) {
//            createProjectTimeStampFile();
//            schemaServiceTestResultsWriter = new SchemaServiceTestResultsWriter(outputDir, "");
//            codingSystemTestResultsWriter = new CodingSystemTestResultsWriter(outputDir);
//            recordCodingSystemOutput("Dataset", "EventType", "Attribute", "CodingSystem", "SearchValue", "NumberOfValues", "ReturnedText");
//            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
//                schemaServiceTestResultsWriter.close();
//                codingSystemTestResultsWriter.close();
//            }));
//        }
//    }


//    private void setFeatureProperties() {
//        dataSource = ConfigLoader.getProperty("dataSource");
//        String template = "dataset/%s.properties";
//        String featurePropertyFilePath = String.format(template, dataSource);
//        try {
//            String path = this.getClass().getClassLoader().getResource(featurePropertyFilePath).getPath();
//            path = path.replace("%40", "@");
//            System.out.println("FILE_PATH=" + path);
//            File file = new File(path);
//            System.out.println("ISFILEEXIST=" + file.exists());
//            TypeRegistryConfiguration.config = ConfigFactory.parseFile(file);
//        } catch (NullPointerException nullPointerException) {
//            testLogger.warning(String.format("Dataset properties file for %s not found.", dataSource));
//        }
//    }



    protected void initializePages(WebDriver driver) {
//        loginPage = new LoginPage(driver);
//        homePage = new HomePage(driver);
    }
}

