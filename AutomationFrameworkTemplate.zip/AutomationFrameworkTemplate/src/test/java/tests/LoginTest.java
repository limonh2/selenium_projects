package tests;

import org.testng.annotations.Test;

public class LoginTest extends BaseClass {

	@Test
	public void login () {
		System.out.println("Test");
	
}
}