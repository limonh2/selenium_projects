package stepDefinitions;

import java.time.Duration;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class InventorySauceDemoSteps {
	public WebDriver driver;
	private By userName = By.id("user-name");
	private By passWord = By.id("password");
	private By loginBtn = By.id("login-button");
	private By shoppingCartIcon = By.id("shopping_cart_container");

	@Given("^user is in the landing page for Sauce Demo enter user name pass$")
	public void user_is_in_the_landing_page_for_sauce_demo_enter_user_name_pass() throws Throwable {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");

		driver = new ChromeDriver(options);

		System.setProperty("webdriver.chrome.driver",
				("C:\\Users\\limon\\eclipse-workspace\\libs\\chromedriver_win32\\chromedriver.exe"));

		driver.get("https://www.saucedemo.com");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		driver.findElement(userName).sendKeys("standard_user");
		driver.findElement(passWord).sendKeys("secret_sauce");
		driver.findElement(loginBtn).click();

		Assert.assertEquals(true, driver.findElement(shoppingCartIcon).isDisplayed());

	}

	@Then("^findElements for inventory print total num of items and get item with max price$")
	public void findelements_for_inventory_print_total_num_of_items_and_get_item_with_max_price() throws Throwable {
///https://www.youtube.com/watch?v=fKicuPJEkJ0
		List<WebElement> list = driver.findElements(By.className("inventory_item_price"));
		System.out.println("Total # of items in page = " + list.size());

		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println("Total # of links =" + links.size());

	}

	@Then("^findElements print all Links of webpage and count how many links for loops$")
	public void findelements_print_all_links_of_webpage_and_count_how_many_links_for_loops() throws Throwable {
		List<WebElement> links = driver.findElements(By.tagName("a"));

		// System.out.println("all links are " + links);
		System.out.println("Total # of links in page = " + links.size());
		//
		//
		for (int i = 0; i < links.size(); i++)
			
		{
System.out.println("Links are " +links.get(i).getAttribute("href"));
System.out.println("Links text is " +links.get(i).getText());
		}

	}
	
	@Then("^findElements get all options from dropdown menu and get total num of options$")
    public void findelements_get_all_options_from_dropdown_menu_and_get_total_num_of_options() throws Throwable {
		List<WebElement> dropdownvalues = driver.findElements(By.tagName("option"));

		// System.out.println("all links are " + links);
		System.out.println("Total # of values in dropdown = " + dropdownvalues.size());
		//
		//
		for (int i = 0; i < dropdownvalues.size(); i++)
			
		{
System.out.println("Options are " + dropdownvalues.get(i).getAttribute("value"));

		}

	}
		
    

	@And("^close browser for sauce demo$")
	public void close_browser_for_sauce_demo() throws Throwable {
		driver.close();
	}
}
