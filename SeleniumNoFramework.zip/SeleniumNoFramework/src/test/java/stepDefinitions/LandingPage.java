package stepDefinitions;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class LandingPage {

	public WebDriver driver;
	public WebElement doubleclickalertBox = driver.findElement(By.id("dblClkBtn"));

	@Given("^user is in the landing page$")
	public void user_is_in_the_landing_page() throws Throwable {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");

		driver = new ChromeDriver(options);

		System.setProperty("webdriver.chrome.driver",
				("C:\\Users\\limon\\eclipse-workspace\\libs\\chromedriver_win32\\chromedriver.exe"));

		driver.get("https://artoftesting.com/samplesiteforselenium");
		/// https://www.saucedemo.com/inventory.html
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@SuppressWarnings("unused")
	@Then("^verify user is in the landing page$")
	public void verify_user_is_in_the_landing_page() throws Throwable {

		// driver.findElement(By.xpath("//input[@value='Male']")).isDisplayed();
		// Assert.assertEquals(true,
		// driver.findElement(By.xpath("//input[@value='Male']")).isDisplayed());

		WebElement textBox = driver.findElement(By.id("fname"));

		WebElement maleRadiobtn = driver.findElement(By.id("male"));
		WebElement femaleRadiobtn = driver.findElement(By.id("female"));
		boolean selectStateoMaleRadioBtn = maleRadiobtn.isSelected();
		boolean selectStateoFemaleRadioBtn = femaleRadiobtn.isSelected();

		boolean selectStateoMaleRadioBtn2 = maleRadiobtn.isEnabled();
		boolean selectStateoFemaleRadioBtn2 = femaleRadiobtn.isEnabled();

		if (selectStateoMaleRadioBtn == false) {
			maleRadiobtn.click();
		}
		Thread.sleep(2000);

		Assert.assertEquals(true, maleRadiobtn.isSelected());
		Thread.sleep(2000);

	}

	@Then("^select \"([^\"]*)\" from dropdown menu$")
	public void select_something_from_dropdown_menu(String strArg1) throws Throwable {

		@SuppressWarnings("unused")
		WebElement dropDownMenu = driver.findElement(By.id("testingDropdown"));

		@SuppressWarnings("unused")
		Select sel = new Select(dropDownMenu);
		sel.selectByVisibleText(strArg1);

		Thread.sleep(2000);

	}

	@Then("^check off checkboxes$")
	public void check_off_checkboxes() throws Throwable {
		WebElement AutomationChkBox = driver.findElement(By.xpath("//input[@value='Automation']"));
		WebElement PerformanceChkBox = driver.findElement(By.xpath("//input[@value='Performance']"));
		boolean AutomationChkBoxState = AutomationChkBox.isSelected();
		boolean PerformChkBoxState = PerformanceChkBox.isSelected();

		if (AutomationChkBoxState == false) {
			AutomationChkBox.click();

		}

		if (PerformChkBoxState == false) {
			PerformanceChkBox.click();

		}

	}

	@Then("^click button to show alert box$")
	public void click_button_to_show_alert_box() throws Throwable {
		WebElement clickalertBox = driver.findElement(By.xpath("//button[normalize-space()='Generate Alert Box']"));

		clickalertBox.click();
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@Then("^double click on button$")
	public void double_click_on_button() throws Throwable {
		@SuppressWarnings("unused")
		
		Actions act = new Actions(driver);
		act.doubleClick(doubleclickalertBox).perform();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		//driver.switchTo().alert().sendKeys("OK");

		Thread.sleep(2000);

	}

	@Then("^click on confirm button$")
	public void click_on_confirm_button() throws Throwable {
		WebElement confirmalertBox = driver.findElement(By.xpath("//button[normalize-space()='Generate Confirm Box']"));
		confirmalertBox.click();
		
		driver.switchTo().alert().accept();
		//driver.switchTo().alert().sendKeys("OK");
		Thread.sleep(2000);
	}
	
	@Then("^getWindowHandles$")
    public void get_windows_handles() throws Throwable {
        
    }

	@And("^close browser$")
	public void close_browser() throws Throwable {
		Thread.sleep(1000);
		driver.close();
	}
}