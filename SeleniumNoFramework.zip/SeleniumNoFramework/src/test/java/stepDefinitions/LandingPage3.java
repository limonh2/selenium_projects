package stepDefinitions;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class LandingPage3 {

	public WebDriver driver;
	public WebElement doubleclickalertBox = driver.findElement(By.id("dblClkBtn"));
	public WebElement textBox = driver.findElement(By.id("fname"));

	public WebElement maleRadiobtn = driver.findElement(By.id("male"));
	public WebElement femaleRadiobtn = driver.findElement(By.id("female"));
	
	public WebElement dropDownMenu = driver.findElement(By.id("testingDropdown"));
	
	public 	WebElement AutomationChkBox = driver.findElement(By.xpath("//input[@value='Automation']"));
	public WebElement PerformanceChkBox = driver.findElement(By.xpath("//input[@value='Performance']"));
	

}