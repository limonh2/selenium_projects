package stepDefinitions;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class LandingPage2 {

	public WebDriver driver;
	private By doubleclickalertBox = (By.id("dblClkBtn"));
	private By textBox = (By.id("fname"));
	private By femaleRadiobtn = (By.id("female"));
	private By maleRadiobtn = (By.id("male"));

	

	

}