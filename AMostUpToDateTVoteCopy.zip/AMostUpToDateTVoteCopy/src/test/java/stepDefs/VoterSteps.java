package stepDefs;


import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import pages.VoterPage;
import utils.Helper;
import utils.SharedDriver;

import java.util.List;
import java.util.Map;


public class VoterSteps {


    public VoterPage voterPage;

    public VoterSteps(SharedDriver driver, VoterPage voterPage) {
        this.voterPage = voterPage;
    }

    @Then("User select {string} from Notice Name dropdown and enter {string} in Notes")
    public void userSelectsNoticeNameAndEnterComments(String noticeType, String comments) {
        voterPage.selectNoticeNameAndAddComments(noticeType, comments);
    }

    @Then("User verify {string} was created successfully")
    public void userVerifyCorrespondenceWasCreatedSuccessfully(String type) {
        voterPage.verifyCorrespondenceTitleCreated(type);
    }

    @When("User enter {string} into Quick Search field")
    public void userEnterIntoQuickSearchField(String text) {
        voterPage.enterIntoQuickSearchField(text);

    }

    @And("User click on Add Registrant button")
    public void userClickOnAddRegistrantButton() {
        voterPage.userClickOnAddRegistrantButton();
        voterPage.waitForSpinner();
    }

    @Then("the new registrant should be added successfully")
    public void theNewRegistrantShouldBeAddedSuccessfully() {
        Assert.assertTrue(voterPage.voterInformationBtn.isDisplayed());
    }

    @And("User deletes any existing Correspondences")
    public void userVerifyYouCanYouDeleteTheCorrespondenceCreated() {
        voterPage.deleteCorrespondenceNotice();
    }

    @And("User updates Mailng Address")
    public void userUpdatesMailngAddress() {
        voterPage.clickUpdateAddressBtn();

        String addressField = Helper.getRandomNumber(3) + " " + Helper.getRandomString(5);
        String citField = Helper.getRandomString(6);
        String zipField = Helper.getRandomNumber(5);

        voterPage.updateAddressField(addressField);
        voterPage.updateCityField(citField);
        voterPage.updateZipField(zipField);
        VoterPage.COMPLETE_ADDRESS = String.format("%s %s AZ %s", addressField, citField, zipField).toUpperCase();
    }

    @And("User updates Mailng Address for NV")
    public void userUpdatesMailngAddressforNV() {
        voterPage.clickUpdateAddressBtn();

        String addressField = Helper.getRandomNumber(3) + " " + Helper.getRandomString(5);
        String citField = Helper.getRandomString(6);
        String zipField = Helper.getRandomNumber(5);

        voterPage.updateAddressField(addressField);
        voterPage.updateCityField(citField);
        voterPage.updateZipField(zipField);
        VoterPage.COMPLETE_ADDRESS_NV = String.format("%s %s NV %s", addressField, citField, zipField).toUpperCase();
    }

    @Then("User verify Address fields were updated successfully")
    public void userVerifyAddressFieldsWereUpdatedSuccessfully() {
        voterPage.verifyResidentialAddress();
    }

    @Then("User verify Address fields were updated successfully for NV")
    public void userVerifyAddressFieldsWereUpdatedSuccessfullyNV() {
        voterPage.verifyResidentialAddressNV();
    }


    @Then("the new UOCAVA military overseas registrant should be added successfully")
    public void theNewUOCAVAMilitaryOverseasRegistrantShouldBeAddedSuccessfully() {
        Assert.assertTrue(voterPage.overseasMilitaryFlag.isDisplayed());
    }

    @And("User select {string} from Form Type dropdown")
    public void userSelectFromFormTypeDropdown(String formType) {
        voterPage.selectFormTypeDropDown(formType);
    }

    @Then("User verify {string} form was created successfully")
    public void userVerifyFormWasCreatedSuccessfully(String type) {
        voterPage.verifyScanFormWasCreated(type);
    }

    @And("user verifies in template {string} the notice displayed in the queue")
    public void userVerfiesNoticesDisplayedInTheQueue(String noticeName) {
        voterPage.verfiesNoticesDisplayedInTheQueue(noticeName);
    }

    @And("User creates unique data for a Registrant")
    public void userCreatesUniqueDataForARegistrant(DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        WebElement input;
        String value = "";
        // Iterate over each row in the DataTable
        for (Map<String, String> row : data) {
            String text = row.get("Text");
            String field = row.get("Field");

            switch (field) {
                case "Last Name":
                case "First Name":
                    value = Helper.getRandomString(6);
                    break;
                case "SSN4":
                    value = Helper.getRandomNumber(4);
                    break;
                case "DL/ID #", "Application Number":
                    value = Helper.getRandomNumber(8);
                    break;
                default:
                    value = text;
            }

            input = voterPage.driver.findElement(By.xpath("//label[contains(text(), '" + field + "')]/following-sibling::*"));
            if (!input.getTagName().equals("input") && !input.getTagName().equals("textarea")) {
                input = voterPage.driver.findElement(By.xpath("//label[contains(text(), '" + field + "')]/following-sibling::*/*"));
            }
            input.click();
            input.clear();
            input.sendKeys(value);

        }
    }


    @And("User updates Mailing Address in NV")
    public void userUpdatesMailingAddressInNV() {
        voterPage.clickUpdateAddressBtn();

        String addressField = Helper.getRandomNumber(3) + " " + Helper.getRandomString(5);
        String citField = Helper.getRandomString(6);
        String zipField = Helper.getRandomNumber(5);

        voterPage.updateAddressField(addressField);
        voterPage.updateCityField(citField);
        voterPage.updateZipField(zipField);
        VoterPage.COMPLETE_ADDRESS = String.format("%s %s NV %s", addressField, citField, zipField).toUpperCase();
    }

    @Then("User verify Address fields were updated successfully in NV")
    public void userVerifyAddressFieldsWereUpdatedSuccessfullyInNV() {
        voterPage.verifyResidentialAddress();
    }

    @Then("User validates the Registration Status is set to {string}")
    public void userValidatesTheStatusIsSetTo(String status) {
        String voterStatus=voterPage.voterStatus.getText().trim();
        Assert.assertEquals(voterStatus,status);
    }

    @And("User enter {string} into Note field")
    public void userEnterIntoNoteField(String text) {
            voterPage.enterIntoNoteField(text);

    }

    @When("User enter {string} into Barcode or Registration ID field")
    public void userEnterIntoRegistrationIDField(String text) {
        voterPage.setBarcode(text);
    }

    @And("User click on {string} report and get count")
    public void userClickOnReport(String arg0) {
        voterPage.getReportCount(arg0);
    }
    @Then("User validates Voter has the Incomplete Reasons is set to {string}")
    public void userValidatesVoterHasTheIncompleteReasonsIsSetTo(String incompReasons) {
        String voterStatus=voterPage.voterIncompleteReasons.getText().trim().replaceAll("\n"," ");;
        Assert.assertEquals(voterStatus,incompReasons);
    }

    @And("User verify report counts matches Task Queue")
    public void userVerifyReportCountsMatchesTaskQueue() {
        voterPage.getCountyMatchesReportAndVerifyWithTaskQueue();

    }
    @And("User verifies and updates Voter Status to Active")
    public void userVerifiesAndUpdatesVoterStatusToActive() {
        voterPage.verifiesAndUpdatesVoterStatusToActive();
    }
    @And("User verifies and updates Voter Status to Canceled")
    public void userVerifiesAndUpdatesVoterStatusToCanceled() {
        voterPage.userVerifiesAndUpdatesVoterStatusToCanceled();
    }
    @Then("User validates the Registration Status Reason is set to {string}")
    public void userValidatesTheRegistrationStatusReasonIsSetTo(String status) {
        String voterStatus=voterPage.voterStatusReason.getText().trim();
        Assert.assertEquals(voterStatus,status);
    }
    @Then("User validates Voter has the Flags is set to {string}")
    public void userValidatesVoterHasTheFlagsIsSetTo(String flag) {
        String voterStatus=voterPage.voterFlags.getText().trim().replaceAll("\n"," ");
        Assert.assertEquals(voterStatus,flag);
    }
    @And("User verifies all Registration information")
    public void userVerifiesAllRegistrationInformation(DataTable dataTable) {
        List<List<String>> labelValues=dataTable.asLists();
        for (List<String> data:labelValues){
            voterPage.verifyRegistrationInformation(data);
        }
    }
    @And("User verifies all Voter information")
    public void userVerifiesAllVoterInformation(DataTable dataTable) {
        List<List<String>> labelValues=dataTable.asLists();
        for (List<String> data:labelValues){
            voterPage.verifyVoterInformation(data);
        }
    }
}
