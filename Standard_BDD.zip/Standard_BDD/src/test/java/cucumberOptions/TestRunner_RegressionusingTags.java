package cucumberOptions;

import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features="src/test/java/features",
		glue ="stepDefinitions",
		monochrome=true,
		tags = "@Assign or @BugRegression or @Claims or @Notes or @SearchClaimantPage or @Tasks or @Letters",
plugin= {"html:target/cucumber.html", "json:target/cucumber.json",
"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
"rerun:target/failed_scenarios.txt"})
public class TestRunner_RegressionusingTags extends AbstractTestNGCucumberTests{

	@Override
	@DataProvider(parallel=true)
	public Object[][] scenarios()
	{
		return super.scenarios();
	}

	@BeforeTest
	public void threadCount(ITestContext context) {
		Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getSuite().setDataProviderThreadCount(2);
		context.getCurrentXmlTest().getSuite().setDataProviderThreadCount(4);
		context.getCurrentXmlTest().getSuite().setPreserveOrder(false);
	}
}


//or @Letters 
//skipped
//@SearchClaimantPage - due to defect LW claims not now displaying in search results
//@Assign             - due to defect LW claims not now displaying in search results