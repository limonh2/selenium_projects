package com.fasttrack.tests;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.ViewClaimantDetailspage;
import com.fasttrack.pages.WorkloadReportpage;

import commonLibs.contracts.IDropdown;
import commonLibs.implementation.ElementControl;

@SuppressWarnings("unused")
public class Tasks extends TestSetup {

	@Test(priority = 0)

	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC00 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//											"Tasks" Test Cases
	@Test(priority = 1)
	/*
	 * Pre-reqs: LW claim only
	 * 
	 * 
	 */

	public void Tasks_01() throws Exception {
		extentTest = extent.createTest("Tasks TC01_Ability to perform Pending Adjudication Manually by the user");

		dashboardpage.claimaintQuickSearch("257628"); // updated 11/11
		viewClaimantDetailspage.LWTab.click();
		extentTest.log(Status.INFO, "Clicked on LW tab");

		String parentWindow7 = driver.getWindowHandle();

		viewClaimantDetailspage.AddNewNoteBtn.click();
		extentTest.log(Status.INFO, "Clicks on Add a New Note button");

		Set<String> handles7 = driver.getWindowHandles();
		for (String childwindowHandle7 : driver.getWindowHandles()) {
			if (!parentWindow7.contentEquals(childwindowHandle7)) {

				driver.switchTo().window(childwindowHandle7);

				viewClaimantDetailspage.SelectNoteType("Life Waiver Task");
				extentTest.log(Status.INFO, "Selects LW Task note from dropdown");

				viewClaimantDetailspage.SelectLWTaskfromDropdown("Pending Adjudication");
				extentTest.log(Status.INFO, "Selects Pending Adjudication task from list");

				viewClaimantDetailspage.ClaimNotesCommentsBox.click();

				viewClaimantDetailspage.EnterCommentstoNotes("Notes added to PA task created");
				extentTest.log(Status.INFO, "Entered comments to PA task");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();
				extentTest.log(Status.INFO, "Clicked on save button");
				Thread.sleep(12000);

				driver.switchTo().window(parentWindow7);
				viewClaimantDetailspage.verifycommentsPATask();
				extentTest.log(Status.INFO, "Verifies comments entered were retained");
				Thread.sleep(5000);

				
				dashboardpage.DashboardTab.click();
				Thread.sleep(5000);
			}
		}
	}

	@Test(priority = 2)
	/*
	 * Pre-reqs: LTD claim with "W4S Received" Task in Pending Status
	 * 
	 * 
	 */

	public void Tasks_04() throws Exception {
		extentTest = extent.createTest("Tasks_04_W4S Received");

		dashboardpage.claimaintQuickSearch("258891"); // updated 11/11

		viewClaimantDetailspage.LTDTab.click();

		String parentWindowT04 = driver.getWindowHandle();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.W4SReceivedTask.click();
		extentTest.log(Status.INFO, "Clicks into W4S Received Task");

		Set<String> handlesT04 = driver.getWindowHandles();
		for (String childwindowHandleT04 : driver.getWindowHandles()) {
			if (!parentWindowT04.contentEquals(childwindowHandleT04)) {

				driver.switchTo().window(childwindowHandleT04);

				viewClaimantDetailspage.VerifyTaskStatusisPending();
				extentTest.log(Status.INFO, "Verfies Status is Pending");

				viewClaimantDetailspage.CoverLetterDownloadlink.click();
				extentTest.log(Status.INFO, "Clicks on the file to download CL file");

				viewClaimantDetailspage.SelectTaskStatusfromDropdown("Completed");
				Thread.sleep(10000);
				extentTest.log(Status.INFO, "Select status Completed");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();
				extentTest.log(Status.INFO, "Clicks on Save button");
				Thread.sleep(5000);

				driver.switchTo().window(parentWindowT04);
				extentTest.log(Status.INFO, "Switch to parent window");

				viewClaimantDetailspage.LTDTab.click();

				viewClaimantDetailspage.W4SReceivedTask.click();
				Thread.sleep(5000);
				driver.switchTo().window(childwindowHandleT04);
				viewClaimantDetailspage.VerifyTaskStatusisCompleted();
				Thread.sleep(5000);
				extentTest.log(Status.INFO, "Verfies status is Completed");
				viewClaimantDetailspage.ClaimNotesWindowCancelBtn.click();
				Thread.sleep(5000);
				driver.switchTo().alert().accept();

				driver.switchTo().window(parentWindowT04);

				dashboardpage.DashboardTab.click();

				Thread.sleep(10000);

				dashboardpage.DashboardTab.click();

			}
		}
	}

	@Test  (enabled=false) //(priority = 3)
	/*
	 * Pre-reqs: LTD claim with "State Withholding Received" Task in Pending Status
	 * 
	 * 
	 */

	public void Tasks_05() throws Exception {
		extentTest = extent.createTest("Tasks_05_State Withholding Received");

		dashboardpage.claimaintQuickSearch("258891"); // updated 11/11

		viewClaimantDetailspage.LTDTab.click();

		String parentWindowT05 = driver.getWindowHandle();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.StateWithholdingReceivedTask.click();
		extentTest.log(Status.INFO, "Clicks into State Withholding Received Task");

		Set<String> handlesT05 = driver.getWindowHandles();
		for (String childwindowHandleT05 : driver.getWindowHandles()) {
			if (!parentWindowT05.contentEquals(childwindowHandleT05)) {

				driver.switchTo().window(childwindowHandleT05);

				viewClaimantDetailspage.VerifyTaskStatusisPending();
				extentTest.log(Status.INFO, "Verfies Status is Pending");

				viewClaimantDetailspage.CoverLetterDownloadlink.click();
				extentTest.log(Status.INFO, "Clicks on the file to download CL file");

				viewClaimantDetailspage.SelectTaskStatusfromDropdown("Completed");
				Thread.sleep(10000);
				extentTest.log(Status.INFO, "Select status Completed");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();
				extentTest.log(Status.INFO, "Clicks on Save button");

				driver.switchTo().window(parentWindowT05);
				// extentTest.log(Status.INFO, "Switch to parent window");
				Thread.sleep(5000);
				viewClaimantDetailspage.LTDTab.click();

				viewClaimantDetailspage.StateWithholdingReceivedTask.click();
				Thread.sleep(1000);
				driver.switchTo().window(childwindowHandleT05);
				viewClaimantDetailspage.VerifyTaskStatusisCompleted();
				Thread.sleep(1000);
				extentTest.log(Status.INFO, "Verfies status is Completed");
				viewClaimantDetailspage.ClaimNotesWindowCancelBtn.click();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();

				driver.switchTo().window(parentWindowT05);

				Thread.sleep(10000);

				dashboardpage.DashboardTab.click();

			}
		}
	}

	@Test(enabled=false) //(priority = 4)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * Need to figure out better solution for Submit button locator
	 */

	public void Tasks_06() throws Exception {
		extentTest = extent.createTest("Tasks_06_FastTrack Proper_Term Reduction Task_LWOP");

		dashboardpage.claimaintQuickSearch("257628"); // old 257826
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		String parentWindowT06 = driver.getWindowHandle();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.TermsAndReductionsBtn.click();

		extentTest.log(Status.INFO, "Clicks on Terms and Reduction button");

		Set<String> handlesT06 = driver.getWindowHandles();
		for (String childwindowHandleT06 : driver.getWindowHandles()) {
			if (!parentWindowT06.contentEquals(childwindowHandleT06)) {
				viewClaimantDetailspage.ReductionValue65.click();
				extentTest.log(Status.INFO, "Radio buttion 65 value clicked on");

				viewClaimantDetailspage.TerminationValue35.click();
				extentTest.log(Status.INFO, "65 value checked off");

				viewClaimantDetailspage.TermsReductSubmitBtn.click();

				driver.switchTo().alert().accept();
				extentTest.log(Status.INFO, "Clicks Submit buttion");

				viewClaimantDetailspage.BenefitReductionRemTask.click();
				extentTest.log(Status.INFO, "Clicks on Reduction task");

				driver.switchTo().window(childwindowHandleT06);

				viewClaimantDetailspage.VerifyTaskStatusisPending();
				extentTest.log(Status.INFO, "Veries status pending");
				viewClaimantDetailspage.ClaimNotesWindowCancelBtn.click();
				driver.switchTo().alert().accept();

				extentTest.log(Status.INFO, "Cancels out of Note Window");

				driver.switchTo().window(parentWindowT06);

				viewClaimantDetailspage.BenefitTerminationRemTask.click();
				extentTest.log(Status.INFO, "Clicks on Terminatination Task");

				driver.switchTo().window(childwindowHandleT06);

				viewClaimantDetailspage.VerifyTaskStatusisPending();
				viewClaimantDetailspage.ClaimNotesWindowCancelBtn.click();
				driver.switchTo().alert().accept();

				extentTest.log(Status.INFO, "Cancels out of Note Window");

				Thread.sleep(10000);

				dashboardpage.DashboardTab.click();
				Thread.sleep(5000);

			}

		}
	}

	@Test(enabled=false) //(priority = 5)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */

	public void Tasks_07() throws Exception {
		extentTest = extent
				.createTest("Tasks_07 FastTrack Proper_ Initiate Setup for 'Request Medical Questionnaire' task");

		dashboardpage.claimaintQuickSearch("257628");

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.LWRequestMedicalQuestionnareBtn.click();

		extentTest.log(Status.INFO, "Clicks on Request Claimaint Questionnaire button");
		viewClaimantDetailspage.MedQuestExpirationDate.click();
		viewClaimantDetailspage.MedQuestExpirationDate.sendKeys("01/01/2030");
		viewClaimantDetailspage.MedQuestExpirationDate.sendKeys(Keys.ENTER);
		extentTest.log(Status.INFO, "Entered expiration Date");

		viewClaimantDetailspage.MedRequest_AuthorizationDoc.click();
		extentTest.log(Status.INFO, "Checked off Authorization Doc");

		viewClaimantDetailspage.MedRequest_CreateBtn.click();
		extentTest.log(Status.INFO, "Clicked on Create button");

		viewClaimantDetailspage.verifyMedicalQuestionnaireTask();
		extentTest.log(Status.INFO, "Verifies task was created");
		Thread.sleep(5000);
		// viewClaimantDetailspage.VerifyHasPendingNoteIconRecent();
		// extentTest.log(Status.INFO, "Verifies task was created has pending icon");
		Thread.sleep(5000);

		dashboardpage.DashboardTab.click();
	}

	@Test(enabled=false) //(priority = 6)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Tasks_08() throws Exception {
		extentTest = extent
				.createTest("Tasks_07 FastTrack Proper_ Initiate Setup for 'Request Medical Questionnaire' task");

		dashboardpage.claimaintQuickSearch("257628"); // updated
//dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.LWRequestMedicalQuestionnareBtn.click();

		extentTest.log(Status.INFO, "Clicks on Request Claimaint Questionnaire button");
		viewClaimantDetailspage.MedQuestExpirationDate.click();
		viewClaimantDetailspage.MedQuestExpirationDate.sendKeys("01/01/2030");
		viewClaimantDetailspage.MedQuestExpirationDate.sendKeys(Keys.ENTER);
		extentTest.log(Status.INFO, "Entered expiration Date");

		viewClaimantDetailspage.MedRequest_AuthorizationDoc.click();
		extentTest.log(Status.INFO, "Checked off Authorization Doc");

		viewClaimantDetailspage.MedRequest_CreateBtn.click();
		extentTest.log(Status.INFO, "Clicked on Create button");

		viewClaimantDetailspage.verifyMedicalQuestionnaireTask();
		extentTest.log(Status.INFO, "Verifies task was created");
		Thread.sleep(5000);
		// viewClaimantDetailspage.VerifyHasPendingNoteIconRecent();
		// extentTest.log(Status.INFO, "Verifies task was created has pending icon");
		Thread.sleep(5000);

		dashboardpage.DashboardTab.click();

	}

	@Test(enabled=false) //(priority = 7)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Tasks_10() throws Exception {
		extentTest = extent.createTest("Tasks_10_FastTrack Proper_Approver Review Completed task_LWoP");

		dashboardpage.claimaintQuickSearch("257628"); // updated
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		String parentWindow10 = driver.getWindowHandle();

		driver.switchTo().window(parentWindow10);

		viewClaimantDetailspage.AddNewNoteBtn.click();
		extentTest.log(Status.INFO, "Clicks on Add a New Note button");
		Thread.sleep(5000);

		Set<String> handles10 = driver.getWindowHandles();
		for (String childwindowHandle10 : driver.getWindowHandles()) {
			if (!parentWindow10.contentEquals(childwindowHandle10)) {

				driver.switchTo().window(childwindowHandle10);

				viewClaimantDetailspage.SelectNoteType("Life Waiver Task");

				viewClaimantDetailspage.SelectLWTaskfromDropdown("Approver Review Completed");
				viewClaimantDetailspage.SelectTaskStatusfromDropdown("Completed");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();

				viewClaimantDetailspage.ClaimNotesCommentsBox.click();

				extentTest.log(Status.INFO, "Entered comments to comment section");
				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();
				extentTest.log(Status.INFO, "Clicks on Save button");

				Thread.sleep(5000);
				driver.switchTo().window(parentWindow10);
				Thread.sleep(5000);
				viewClaimantDetailspage.VerifyHasCompletedIconMostRecent();
				extentTest.log(Status.INFO, "Verifies that Completed icon is displayed.");

				dashboardpage.DashboardTab.click();

			}
		}
	}

	@Test(enabled=false) //(priority = 8)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Tasks_11() throws Exception {
		extentTest = extent.createTest("Tasks_11_FastTrack Upload_File_Proper_VCM/DMR referral_LWoP");

		dashboardpage.claimaintQuickSearch("257628"); // updated
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		String parentWindow10 = driver.getWindowHandle();

		driver.switchTo().window(parentWindow10);

		viewClaimantDetailspage.AddNewNoteBtn.click();
		extentTest.log(Status.INFO, "Clicks on Add a New Note button");
		Thread.sleep(5000);

		Set<String> handles10 = driver.getWindowHandles();
		for (String childwindowHandle10 : driver.getWindowHandles()) {
			if (!parentWindow10.contentEquals(childwindowHandle10)) {

				driver.switchTo().window(childwindowHandle10);

				viewClaimantDetailspage.SelectNoteType("Life Waiver Task");

				viewClaimantDetailspage.SelectLWTaskfromDropdown("DMR Review - Vocational");
				viewClaimantDetailspage.SelectTaskStatusfromDropdown("Completed");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();

				viewClaimantDetailspage.ClaimNotesCommentsBox.click();

				extentTest.log(Status.INFO, "Entered comments to comment section");

				// UPload an excel file to complete test

				Actions act = new Actions(driver);

				WebElement chooseFile = driver.findElement(By.id(
						"ctl00_ctl00_MainContent_MainContent_ClaimantNote_AttachmentControl1_AjaxFileUpload1_Html5InputFile"));

				act.moveToElement(chooseFile).perform();
				Thread.sleep(2000);

				chooseFile.sendKeys(
						"C:\\Users\\limon.hossain\\eclipse-workspace\\UploadFilesforTestCases\\TestCaseTasks_11.xls");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();
				extentTest.log(Status.INFO, "Clicks on Save button");

				Thread.sleep(5000);
				driver.switchTo().window(parentWindow10);
				Thread.sleep(5000);
				viewClaimantDetailspage.VerifyHasCompletedIconMostRecent();
				extentTest.log(Status.INFO, "Verifies that Completed icon is displayed.");

				dashboardpage.DashboardTab.click();

			}
		}
	}

	@Test(enabled=false) //(priority = 9)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Tasks_12() throws Exception {
		extentTest = extent
				.createTest("Tasks_12_FastTrack Proper_ DMR Review Completed_UploadFile and assign to analyst_LWoP");

		dashboardpage.claimaintQuickSearch("257628"); // updated
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		String parentWindow10 = driver.getWindowHandle();

		driver.switchTo().window(parentWindow10);

		viewClaimantDetailspage.AddNewNoteBtn.click();
		extentTest.log(Status.INFO, "Clicks on Add a New Note button");
		Thread.sleep(5000);

		Set<String> handles10 = driver.getWindowHandles();
		for (String childwindowHandle10 : driver.getWindowHandles()) {
			if (!parentWindow10.contentEquals(childwindowHandle10)) {

				driver.switchTo().window(childwindowHandle10);

				viewClaimantDetailspage.SelectNoteType("Life Waiver Task");

				viewClaimantDetailspage.SelectLWTaskfromDropdown("DMR Review Completed - Vocational");
				viewClaimantDetailspage.SelectTaskStatusfromDropdown("Completed");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();

				viewClaimantDetailspage.ClaimNotesCommentsBox.click();

				extentTest.log(Status.INFO, "Entered comments to comment section");

				// UPload an excel file to complete test
				viewClaimantDetailspage.AttachmentsTab.click();

				viewClaimantDetailspage.RemindersTab.click();
				viewClaimantDetailspage.SelectCaseWorker2.click();

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();
				extentTest.log(Status.INFO, "Clicks on Save button");

				Thread.sleep(5000);
				driver.switchTo().window(parentWindow10);
				Thread.sleep(5000);
				viewClaimantDetailspage.VerifyHasCompletedIconMostRecent();
				extentTest.log(Status.INFO, "Verifies that Completed icon is displayed.");

				dashboardpage.DashboardTab.click();

			}
		}
	}

	@Test(enabled=false) //(priority = 10)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Tasks_13() throws Exception {
		extentTest = extent.createTest("Tasks_13_FastTrack Proper_ Misc document- POA/Guardian");

		dashboardpage.claimaintQuickSearch("257628"); // updated
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		String parentWindow10 = driver.getWindowHandle();

		driver.switchTo().window(parentWindow10);

		viewClaimantDetailspage.AddNewNoteBtn.click();
		extentTest.log(Status.INFO, "Clicks on Add a New Note button");
		Thread.sleep(5000);

		Set<String> handles10 = driver.getWindowHandles();
		for (String childwindowHandle10 : driver.getWindowHandles()) {
			if (!parentWindow10.contentEquals(childwindowHandle10)) {

				driver.switchTo().window(childwindowHandle10);

				viewClaimantDetailspage.SelectNoteType("Life Waiver Task");

				viewClaimantDetailspage.SelectLWTaskfromDropdown("DMR Review - Vocational");
				viewClaimantDetailspage.SelectTaskStatusfromDropdown("Completed");

				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();

				viewClaimantDetailspage.ClaimNotesCommentsBox.click();

				extentTest.log(Status.INFO, "Entered comments to comment section");

				// UPload an excel file to complete test
				viewClaimantDetailspage.ClaimNotesWindowSaveBtn.click();
				extentTest.log(Status.INFO, "Clicks on Save button");

				Thread.sleep(5000);
				driver.switchTo().window(parentWindow10);
				Thread.sleep(5000);
				viewClaimantDetailspage.VerifyHasCompletedIconMostRecent();
				extentTest.log(Status.INFO, "Verifies that Completed icon is displayed.");

				dashboardpage.DashboardTab.click();

			}
		}
	}

	/// Need to review whats below here

	@Test(enabled = false) // (priority = 13)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Tasks_23_Tasks_24() throws Exception {
		extentTest = extent.createTest("Tasks_23_&_Tasks_24_LWOP FastTrack Proper_Search for all Documents_LWoP");

		dashboardpage.claimaintQuickSearch("257990");
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.DocumentsTab.click();
		Thread.sleep(2000);

		viewClaimantDetailspage.CASTab.click();
		extentTest.log(Status.INFO, "Documents tab was clicked and CAS tab was clicked");
		viewClaimantDetailspage.CASIncompleteFormRequestType.isDisplayed();
		viewClaimantDetailspage.CASIncompleteFormRequestFile.isDisplayed();
		extentTest.log(Status.INFO, "Verfies CAS tab");

		Thread.sleep(2000);
		viewClaimantDetailspage.SystemGeneratedTab.click();
		viewClaimantDetailspage.SGInitialAcknowLetterType.isDisplayed();
		viewClaimantDetailspage.SGInitialAcknowLetterFile.isDisplayed();
		extentTest.log(Status.INFO, "Verfies SG tab");
		Thread.sleep(2000);

		viewClaimantDetailspage.ImagingNotesTab.click();
		viewClaimantDetailspage.ImagingNotesPCFDocType.isDisplayed();
		viewClaimantDetailspage.ImagingNotesPCFDocFile.isDisplayed();
		extentTest.log(Status.INFO, "Verfies Imaging tab");
		Thread.sleep(2000);

		viewClaimantDetailspage.PendingTab.click();
		viewClaimantDetailspage.PendingTabIncompleteFormRequest.isDisplayed();
		extentTest.log(Status.INFO, "Verfies Pending tab");
		Thread.sleep(2000);

		dashboardpage.DashboardTab.click();

	}

	@Test(enabled = false) // (priority = 14)
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Tasks_25() throws Exception {
		extentTest = extent.createTest("Tasks_25_FastTrack Proper_Search Attachments on a claim_LWoP");

		dashboardpage.claimaintQuickSearch("257990");
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		String parentWindow25 = driver.getWindowHandle();

		driver.switchTo().window(parentWindow25);

		viewClaimantDetailspage.ViewAllClaimantActivityBtn.click();
		viewClaimantDetailspage.VAC_ViewBtn.click();
		extentTest.log(Status.INFO, "CLicks on ViewAllClaimantActivity button and View button");

		Set<String> handles25 = driver.getWindowHandles();
		for (String childwindowHandle25 : driver.getWindowHandles()) {
			if (!parentWindow25.contentEquals(childwindowHandle25)) {

				driver.switchTo().window(childwindowHandle25);

				viewClaimantDetailspage.CoverLetterDownloadlink.isDisplayed();
				Thread.sleep(2000);
				extentTest.log(Status.INFO, "Verify there is an attachment");
				viewClaimantDetailspage.ClaimNotesWindowCancelBtn.click();
				driver.switchTo().alert().accept();

				driver.switchTo().window(parentWindow25);
				dashboardpage.DashboardTab.click();

			}
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//										"Assign" Test Cases
	@Test(enabled = false) // (priority = 1)// (groups={"Tasks"})
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Assign_01() throws Exception {
		extentTest = extent.createTest("Tasks_01_LWOP_Assign claim to analyst");

		dashboardpage.claimaintQuickSearch("246526");
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.UnassignStatusBtn.click();
		driver.switchTo().alert().accept();
		extentTest.log(Status.INFO, "Clicks on Unassign and clicks OK button");
		Thread.sleep(2000);

		viewClaimantDetailspage.WelcomeBackTitle.isDisplayed();

		extentTest.log(Status.INFO, "Verify the Welcome Back title is displayed");

		dashboardpage.claimaintQuickSearch("250117");
		viewClaimantDetailspage.AssignBtn.click();
		viewClaimantDetailspage.AssignClaimantDropdown("EST 26001");
		extentTest.log(Status.INFO, "Assings new assignee");
		viewClaimantDetailspage.Assign2Btn.click();
		extentTest.log(Status.INFO, "Clicks on Assign button");
		Thread.sleep(2000);
		viewClaimantDetailspage.VerifyAssignee("Life Waiver (EST 26001)", "Life Waiver (EST 26001)");
		extentTest.log(Status.INFO, "Verifies current Assinee for claim");
		Thread.sleep(2000);
		dashboardpage.DashboardTab.click();

	}

	@Test(enabled = false) // (priority = 1) //(priority = 1)// (groups={"Tasks"})
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Assign_02() throws Exception {
		extentTest = extent.createTest("Tasks_02_LWOP_Reassign claim to new analyst");

		dashboardpage.claimaintQuickSearch("246526");
		// dashboardpage.SecondClaimaintSearchResultsClick.click();

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.ReassignStatusBtn.click();

		extentTest.log(Status.INFO, "Clicks on Reassign");
		Thread.sleep(2000);

		// viewClaimantDetailspage.WelcomeBackTitle.isDisplayed();

		// extentTest.log(Status.INFO, "Verify the Welcome Back title is displayed");

		viewClaimantDetailspage.AssignClaimantDropdown("EST 26002");
		extentTest.log(Status.INFO, "Assings new assignee");
		viewClaimantDetailspage.Assign2Btn.click();
		extentTest.log(Status.INFO, "Clicks on Assign button");
		Thread.sleep(2000);
		viewClaimantDetailspage.VerifyAssignee("Life Waiver (EST 26002)", "Life Waiver (EST 26002)");
		extentTest.log(Status.INFO, "Verifies current Assinee for claim");
		Thread.sleep(2000);
		dashboardpage.DashboardTab.click();

	}

}