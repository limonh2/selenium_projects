package com.fasttrack.tests._TestRunTemplate;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.ViewClaimantDetailspage;
import com.fasttrack.pages.WorkloadReportpage;

import commonLibs.contracts.IDropdown;
import commonLibs.implementation.ElementControl;

@SuppressWarnings("unused")
public class ViewClaimantDetailsTests_Assign extends TestSetup {

	@Test(priority = 0)

	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC00 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//										"Assign" Test Cases
	@Test(priority = 1) // (groups={"Tasks"})
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Assign_01() throws Exception {
		extentTest = extent.createTest("Tasks_01_LWOP_Assign claim to analyst");

		dashboardpage.claimaintQuickSearch("257427"); // old246526

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.UnassignStatusBtn.click();
		driver.switchTo().alert().accept();
		extentTest.log(Status.INFO, "Clicks on Unassign and clicks OK button");
		Thread.sleep(2000);

		dashboardpage.claimaintQuickSearch("257427");
		viewClaimantDetailspage.AssignBtn.click();
		
		Thread.sleep(3000);

		viewClaimantDetailspage.AssignClaimantDropdown("EST 26001");
		extentTest.log(Status.INFO, "Assings new assignee");
		viewClaimantDetailspage.Assign2Btn.click();
		extentTest.log(Status.INFO, "Clicks on Assign button");
		Thread.sleep(2000);
		viewClaimantDetailspage.VerifyAssignee("Life Waiver (EST 26001)", "Life Waiver (EST 26001)");
		extentTest.log(Status.INFO, "Verifies current Assinee for claim");
		Thread.sleep(2000);
		dashboardpage.DashboardTab.click();

	}

	@Test (priority = 2) //(groups={"Tasks"})
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Assign_02() throws Exception {
		extentTest = extent.createTest("Tasks_02_LWOP_Reassign claim to new analyst");

		dashboardpage.claimaintQuickSearch("257427");
		

		viewClaimantDetailspage.LWTab.click();

		extentTest.log(Status.INFO, "Goes into the claim");

		viewClaimantDetailspage.ReassignStatusBtn.click();

		extentTest.log(Status.INFO, "Clicks on Reassign");
		Thread.sleep(2000);

		viewClaimantDetailspage.AssignClaimantDropdown("EST 26002");
		extentTest.log(Status.INFO, "Assings new assignee");
		viewClaimantDetailspage.Assign2Btn.click();
		extentTest.log(Status.INFO, "Clicks on Assign button");
		Thread.sleep(2000);
		viewClaimantDetailspage.VerifyAssignee("Life Waiver (EST 26002)", "Life Waiver (EST 26002)");
		extentTest.log(Status.INFO, "Verifies current Assinee for claim");
		Thread.sleep(2000);
		dashboardpage.DashboardTab.click();

	}

	@Test (priority = 3) // (groups={"Tasks"})
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Assign_03() throws Exception {
		extentTest = extent.createTest("Tasks_03_LWOP_Automated Claim assignment");

		dashboardpage.workloadReportTab.click();
		extentTest.log(Status.INFO, "Goes into WLR page");
		Thread.sleep(5000);

		workloadReportpage.STDPendingAssignedTasks.click();
		Thread.sleep(2000);
		extentTest.log(Status.INFO, "Clicks on Pending Assign tasks report ");

		Thread.sleep(30000);
		workloadReportpage.WLRResultsGrid.isDisplayed();
		
		extentTest.log(Status.INFO, "Results grid is displayed, PASS ");
		dashboardpage.DashboardTab.click();

	}
}
