package com.fasttrack.tests;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.Loginpage;

public class LoginpageTests extends TestSetup {

	@Test(priority = 0)
	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC1 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);
		
		extentTest.log(Status.INFO, "User is logged into the carrier site.");

	}
}
