package com.fasttrack.tests;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class DashboardTests extends TestSetup {

	@Test(priority = 0)
	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC1 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

	@Test(priority = 1)
	public void VerifyWLReports() throws Exception {

		extentTest = extent.createTest("TC01 - Verify WLR");
		dashboardpage.QuickSearch.sendKeys("McCoy");
		dashboardpage.QuickSearch.sendKeys(Keys.RETURN);
		Thread.sleep(5000);
		dashboardpage.SearchResultTable.click();
		
		Thread.sleep(5000);
		
		dashboardpage.InsuredDeatilsTitle.isDisplayed();
		Thread.sleep(5000);
		dashboardpage.wlrink.click();
		extentTest.log(Status.INFO, "WLR link was clicked");

		Thread.sleep(5000);

	}
}
