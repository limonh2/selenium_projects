package com.fasttrack.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class _TestCaseTestRun extends TestSetup {

	@Test(priority = 0)
	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC1 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

	@Test(priority = 1)
	public void claimaintQuickSearchTest() throws Exception {
		dashboardpage.claimaintQuickSearch("208062");
		
		Thread.sleep(100000);
		
	}
}
