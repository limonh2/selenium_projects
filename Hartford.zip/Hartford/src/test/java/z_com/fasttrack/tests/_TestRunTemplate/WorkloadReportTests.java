package z_com.fasttrack.tests._TestRunTemplate;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class WorkloadReportTests extends TestSetup {

	@Test(priority = 0)
	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC1 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

	@Test(priority = 1)
	public void xxx() throws Exception {

		//extentTest = extent.createTest("xxxxx");
		
				
		dashboardpage.selectLWProduct();
		

	}
}
