package z_com.fasttrack.tests._TestRunTemplate;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.fasttrack.pages.AddClaimantpage;
import com.fasttrack.pages.Dashboardpage;
import com.fasttrack.pages.Loginpage;
import com.fasttrack.pages.ManagerReportpage;
import com.fasttrack.pages.SearchClaimantpage;
import com.fasttrack.pages.ViewClaimantDetailspage;
import com.fasttrack.pages.WorkloadReportpage;
import com.fasttrack.utils.ConfigReader;

import commonLibs.implementation.CommonDriver;
import commonLibs.implementation.ScreenshotControl;
import commonLibs.utils.DateUtils;

public class TestSetup {

	CommonDriver cmnDriver;
	WebDriver driver;

	// UPDATE HERE FOR NEW  PAGES 1 of 2 area
	Dashboardpage dashboardpage;
	Loginpage loginpage;
	ViewClaimantDetailspage viewClaimantDetailspage;
	AddClaimantpage addClaimantpage;
	WorkloadReportpage workloadReportpage;
	SearchClaimantpage searchClaimantpage;
	ManagerReportpage managerReportpage;

	Properties configProperty;
	String configFilePath;
	String currentWorkingDirectory;

	String executionStartTime;

	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest extentTest;

	ScreenshotControl screenshot;

	@BeforeSuite
	public void presetup() throws Exception {

		startExecutionTime();

		initializeCurrentWorkingDirectoryPath();

		readConfigurationPropertiesFile();

		initializeReport();
		
		
	}

	
	@BeforeClass(alwaysRun = true)
	public void setup() throws Exception {
		
				
		extentTest = extent.createTest("Setup : Invoking Browser");

		extentTest.log(Status.INFO, "Invoking Browser");
		invokeBrowser();

		initializeScreenshotInstance();

		extentTest.log(Status.INFO, "Initializing pages");
		initializePages();
		
		
	}

	private void initializeScreenshotInstance() {
		screenshot = new ScreenshotControl(driver);

	}

	@AfterClass(alwaysRun = true)

	public void cleanup() throws Exception {
		extentTest = extent.createTest("Clean up :Closing Browser");
		cmnDriver.closeAllBrowsers();
		extentTest.log(Status.INFO, "All browsers closed");
	}

	@AfterSuite
	public void postCleanup() {
		extent.flush();
	}

	@AfterMethod
	public void afterAMethod(ITestResult result) throws Exception {
		String methodName = result.getName();
		if (result.getStatus() == ITestResult.SUCCESS) {
			extentTest.log(Status.PASS, "Test case pass - " + methodName);
		} else if (result.getStatus() == ITestResult.FAILURE) {
			extentTest.log(Status.FAIL, "Test case pass - " + methodName);

			captureTheScreenshotAndSaveItInReport(methodName);

		} else {
			extentTest.log(Status.SKIP, "Test case pass - " + methodName);
		}

	}

	//Captures screenshot at the step which it fails
	private void captureTheScreenshotAndSaveItInReport(String methodName) throws Exception {
		String screenshotFileName = String.format("%s/screenshots/%s_%s.jpeg", currentWorkingDirectory, methodName,
				executionStartTime);

		screenshot.captureAndSaveScreenshot(screenshotFileName);

		extentTest.addScreenCaptureFromPath(screenshotFileName);

	}

	// // UPDATE HERE FOR NEW  PAGES 2 of 2 area
	private void initializePages() {
		extentTest.log(Status.INFO, "Initialized homepage instance");
		dashboardpage = new Dashboardpage(driver);
		loginpage = new Loginpage(driver);
		viewClaimantDetailspage = new ViewClaimantDetailspage(driver);
		addClaimantpage = new AddClaimantpage(driver);
		workloadReportpage = new WorkloadReportpage(driver);
		searchClaimantpage = new SearchClaimantpage(driver);
		managerReportpage = new ManagerReportpage(driver);

	}

	private void startExecutionTime() {
		executionStartTime = DateUtils.getDate();
	}

	private void initializeReport() {
		String reportFilename = String.format("%s/reports/FastTrack_Summary_Test_Report_%s.html", currentWorkingDirectory,
				executionStartTime);

		htmlReporter = new ExtentHtmlReporter(reportFilename);
		extent = new ExtentReports();

		extent.attachReporter(htmlReporter);
	}

	private void readConfigurationPropertiesFile() throws Exception {
		configFilePath = String.format("%s/config/config.properties", currentWorkingDirectory);

		configProperty = ConfigReader.readConfigProperties(configFilePath);
	}

	private void invokeBrowser() throws Exception {
		extentTest.log(Status.INFO, "Initializing common Driver instance");
		cmnDriver = new CommonDriver(configProperty.getProperty("browserType"));

		int pageLoadTime = Integer.parseInt(configProperty.getProperty("pageLoadTimeout"));
		cmnDriver.setPageloadTimeout(pageLoadTime);
		extentTest.log(Status.INFO, "Initailized page load time out");

		int elementDetectionTimeout = Integer.parseInt(configProperty.getProperty("elementDetectionTimeout"));
		cmnDriver.setElementDetectionTimeout(elementDetectionTimeout);
		cmnDriver.navigateToFirstUrl(configProperty.getProperty("baseUrl"));

		driver = cmnDriver.getDriver();

	}

	private void initializeCurrentWorkingDirectoryPath() {
		currentWorkingDirectory = System.getProperty("user.dir");
	}

}
