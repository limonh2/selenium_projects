package z_com.fasttrack.tests._TestRunTemplate;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.ViewClaimantDetailspage;
import com.fasttrack.pages.WorkloadReportpage;

import commonLibs.contracts.IDropdown;
import commonLibs.implementation.ElementControl;

@SuppressWarnings("unused")
public class ViewClaimantDetailsTests_Assign_Template extends TestSetup {

	@Test(priority = 0)

	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC00 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//										"Assign" Test Cases
	@Test(priority = 1) // (groups={"Tasks"})
	/*
	 * Pre-reqs: LW claim
	 * 
	 * 
	 */
	public void Assign_01() throws Exception {
		extentTest = extent.createTest("Tasks_01_LWOP_Assign claim to analyst");

		dashboardpage.claimaintQuickSearch("257427"); // old246526

		viewClaimantDetailspage.LWTab.click();

		

	}

}