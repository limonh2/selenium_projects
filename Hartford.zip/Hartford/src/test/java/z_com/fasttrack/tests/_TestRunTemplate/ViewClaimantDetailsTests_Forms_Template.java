package z_com.fasttrack.tests._TestRunTemplate;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.ViewClaimantDetailspage;
import com.fasttrack.pages.WorkloadReportpage;

import commonLibs.contracts.IDropdown;
import commonLibs.implementation.ElementControl;

@SuppressWarnings("unused")
public class ViewClaimantDetailsTests_Forms_Template extends TestSetup {

	@Test(priority = 0)

	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC00 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//													"Forms" Test Cases	

	@Test(priority = 1) // (groups={"Forms"})
	/*
	 * Pre-reqs:
	 * 
	 * 
	 */

	public void Forms_01a() throws Exception {
		extentTest = extent
				.createTest("Forms_01a_Send out a Form without a letter and the system creates a note for that task");

		dashboardpage.claimaintQuickSearch("257910 ");

		dashboardpage.DashboardTab.click();

	}
}
