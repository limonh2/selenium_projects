package z_com.fasttrack.tests._TestRunTemplate;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasttrack.pages.ViewClaimantDetailspage;
import com.fasttrack.pages.WorkloadReportpage;

import commonLibs.contracts.IDropdown;
import commonLibs.implementation.ElementControl;

@SuppressWarnings("unused")
public class ViewClaimantDetailsTests_Reports_Template extends TestSetup {

	@Test(priority = 0)

	public void verifyUserLoginToCarrier() throws Exception {

		extentTest = extent.createTest("TC00 - Verify User Login to the Carrier site");

		String userName = configProperty.getProperty("userName");
		String userPassword = configProperty.getProperty("userPassword");
		loginpage.userLogin(userName, userPassword);

		extentTest.log(Status.INFO, "User is logged into the carrier site.");
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//													"Forms" Test Cases	

	@Test(enabled = false) // (groups={"Forms"})
	/*
	 * Pre-reqs: Need 1 OR ready to View and 1 more which needs to Queue to
	 * Recompare
	 * 
	 * 
	 */
	public void Reports_01() throws Exception {
		extentTest = extent.createTest("Report_01_Ability to view existing Opportunity Report for a claim");

		dashboardpage.claimaintQuickSearch("28186"); // useforfinal 28186

		dashboardpage.DashboardTab.click();

	}
}
