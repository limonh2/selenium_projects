package com.fasttrack.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import commonLibs.implementation.ElementControl;

public class Dashboardpage extends BaseInitialization {

	//@FindBy(xpath = "//label[normalize-space()='Add New Claimant']")

	
	
	
	
	
	// SSN Quick Search

	// Occupation Quick Search
	
	///WorldLoad Report
	
	@FindBy(id = "ctl00_ctl00_TopMenu1_anchorTaskReport")
	public WebElement workloadReportTab;

	public Dashboardpage(WebDriver driver) {

		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void claimaintQuickSearch(String claimantID) throws Exception {
		elementControl.setText(DashboardClaimantquickSearch, claimantID);
		elementControl.clickElement(DashboardcqsSearchBtn);
	
		
			

	}
	
	public void claimaintQuickSearch2(String claimantID) throws Exception {
		elementControl.setText(DashboardClaimantquickSearch, claimantID);
		elementControl.clickElement(DashboardcqsSearchBtn);
		// elementControl.clickElement(recert1streqBtn);

	}
	
	public void ClickonclaimfromSearchResultsWindow(String claimantID) throws Exception {
		elementControl.setText(DashboardClaimantquickSearch, claimantID);
		elementControl.clickElement(DashboardcqsSearchBtn);
		
				
		// elementControl.clickElement(recert1streqBtn);

	}

	public void createOwner(String OOfirstName, String OOlastName, String OOaddress, String OOcity, String OOstate,
			String OOzipCode) throws Exception {
		// elementControl.clickElement(addnewClaimant);
		elementControl.setText(OfirstName, OOfirstName);
		elementControl.setText(OlastName, OOlastName);
		elementControl.setText(Oaddress, OOaddress);
		elementControl.setText(Ocity, OOcity);
		elementControl.setText(Ostate, OOstate);
		elementControl.setText(OzipCode, OOzipCode);
		elementControl.clickElement(commitownerBtn);
		Thread.sleep(5000);
	}

	public void enterpolicyNumber(String ppolicyNumber) throws Exception {
		elementControl.setText(policyNumber, ppolicyNumber);
	}

	public void selectLWProduct() throws Exception {
		elementControl.clickElement(addnewClaimant);
		elementControl.clickElement(productLW);
		Thread.sleep(5000);

	}

	public void selectProductDI_LTD() throws Exception {
		elementControl.clickElement(productDI_LTD);
		elementControl.clickElement(addBtn);
		Thread.sleep(5000);

	}

	public void createnewClaimant(String sfirstName, String slastName, String saddress, String scity, String sstate,
			String szipCode, String ddateofBirth, String ddateclaimRecieved, String bbeginbenefitDate,
			String iinsuranceAgency) throws Exception {
		elementControl.setText(firstName, sfirstName);
		elementControl.setText(lastName, slastName);
		elementControl.setText(address, saddress);
		elementControl.setText(city, scity);
		elementControl.setText(state, sstate);
		elementControl.setText(zipCode, szipCode);
		Thread.sleep(5000);

		elementControl.clickElement(dateofBirth);
		elementControl.setText(dateofBirth, ddateofBirth);
		Thread.sleep(5000);
		elementControl.clickElement(dateclaimReceived);
		elementControl.setText(dateclaimReceived, ddateclaimRecieved);
		Thread.sleep(5000);
		// elementControl.clickElement(beginbenefitDate);
		// elementControl.setText(beginbenefitDate, bbeginbenefitDate);
		elementControl.clickElement(zipCode);

		// elementControl.clickElement(insuranceAgency);
		// elementControl.setText(insuranceAgency, iinsuranceAgency);
		elementControl.clickElement(zipCode);

		Thread.sleep(5000);

		elementControl.clickElement(saveBtn);
		Thread.sleep(5000);

		String expectedWelcomeText = "Claimant was successfully added!";
		String actualWelcomeText = elementControl.getText(successMessage);

		Assert.assertEquals(actualWelcomeText, expectedWelcomeText);
		// elementControl.clickElement(gotoclaimantDetailsBtn);
		// Thread.sleep(10000);

	}

	// public void claimantQuickSearch() throws Exception {
	// elementControl.clickElement(productDI_LTD);
	// elementControl.clickElement(addBtn);
	// Thread.sleep(5000);

	// }

}
