package commonLibs.contracts;

public interface IScreenshots {

	public String captureAndSaveScreenshot(String fileName) throws Exception;
}
