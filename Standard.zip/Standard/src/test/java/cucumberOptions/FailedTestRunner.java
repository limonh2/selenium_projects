package cucumberOptions;

import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//s
@CucumberOptions(
		features="@target/failed_scenarios.txt",glue ="stepDefinitions",
		monochrome=true,
		//tags = "@Assign or @BugRegression or @Claims or @Letters or @Notes or @SearchClaimantPage or @Tasks",
		plugin= {"html:target/cucumber.html", "json:target/cucumber.json",
"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
})
public class FailedTestRunner extends AbstractTestNGCucumberTests{

	@Override
	@DataProvider(parallel=true)
	public Object[][] scenarios()
	{
		return super.scenarios();
	}


	@BeforeTest
	public void threadCount(ITestContext context) {
		context.getCurrentXmlTest().getSuite().setDataProviderThreadCount(1);
		context.getCurrentXmlTest().getSuite().setPreserveOrder(false);

	}
	}

//Notes 05 Tasks 07 Assign o1