package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utils.Base;
import utils.DriverFactory;
import utils.Helper;

import java.util.List;
import java.util.NoSuchElementException;


public class VoterPage extends Base {

    JavascriptExecutor js = ((JavascriptExecutor) DriverFactory.getDriver());

    public static String COMPLETE_ADDRESS;
    public static String officeName;

    public VoterPage() {
        PageFactory.initElements(DriverFactory.getDriver(), this);
    }


    @FindBy(xpath = "//div[@style='display: block;']//select[@id='notice-template-select']")
    public WebElement drpNoticeName;

    @FindBy(xpath = "//div[@style='display: block;']//textarea[@data-testid=\"notes\"]")
    public WebElement inpNotesComments;

    @FindBy(xpath = "//div[@style='display: block;']//button[normalize-space()=\"Insert\"]")
    public WebElement btnInsert;

    @FindBy(xpath = "//input[@placeholder='Last Name, First']")
    public WebElement inpQuickSearch;

    @FindBy(css = ".ms-3")
    public WebElement addButton;

    @FindBy(xpath = "//button[contains(text(),'Information')]")
    public WebElement voterInformationBtn;

    @FindBy(xpath = "//button[normalize-space()='Delete' and contains(@class,'confirm')]")
    public WebElement noticeConfirmDeleteBtn;

    @FindBy(xpath = "//button[normalize-space()='Cancel' and contains(@class,'cancel')]")
    public WebElement noticeConfirmCancelBtn;

    @FindBy(xpath = "//button[text() = 'Delete']")
    public WebElement noticeDeleteBtn;

    @FindBy(xpath = "//button[text() = 'Delete']")
    public List<WebElement> noticeDeleteButton;

    @FindBy(xpath = "//button[text() = 'OK']")
    public WebElement noticeConfirmOKBtn;

    @FindBy(xpath = "//label[contains(text(), 'Address')]/parent::div//input[not(@disabled)]")
    public WebElement addressInp;

    @FindBy(xpath = "//label[contains(text(), 'City')]/parent::div//input")
    public WebElement cityInp;

    @FindBy(xpath = "//label[contains(text(), 'Zip')]/following-sibling::input[not(@disabled)]")
    public WebElement zipInp;

    @FindBy(xpath = "//div[@data-testid='residential_address']")
    public WebElement addressResidential;

    @FindBy(xpath = " //button[contains(text(),'Update')]")
    public WebElement updateAddressBtn;

    @FindBy(xpath = " //div[text()='UOCAVA: Overseas Military' and @data-testid='flag']")
    public WebElement overseasMilitaryFlag;

    @FindBy(xpath = "//textarea[@data-testid='note']")
    public WebElement inputNote;

    @FindBy(xpath = "//button[text() = 'Note']")
    public WebElement noteBtn;

    @FindBy(css = ".text-danger")
    public WebElement requiredNoteMessage;

    @FindBy(xpath = "//div[./span[text()='Status']]/following-sibling::div")
    public WebElement voterStatus;
    @FindBy(xpath = "//input[@data_test_id='registrant_search']")
    public WebElement barcodeField;

    @FindBy(xpath = "//div[./span[text()='Incomplete Reasons']]/following-sibling::div")
    public WebElement voterIncompleteReasons;

    @FindBy(xpath = "//span[@data-testid='total_size']")
    public List<WebElement> outOfCountyMatchesReportCount;

    @FindBy(xpath = "//span[@data-testid='total_size']")
    public WebElement searchResultCount;

    @FindBy(xpath = "//input[@id='PartySinceDate']")
    public WebElement PartySinceDateCalendarPicker;

    @FindBy(xpath = "//div[contains(@class, 'col-lg-8')]//div[contains(text(), 'Confidential')]")
    public WebElement voterProfileFlagLabel;

    @FindBy(xpath = "//div[contains(@class, 'col-lg-8')]//div[contains(text(), 'Secure')]")
    public WebElement voterProfileSecureFlagLabel;

    @FindBy(css = ".voter-header i.fa-map-marker-alt")
    public WebElement mapLocator;

    @FindBy(xpath = "//label[normalize-space()='Document Is Signed']//preceding-sibling::*")
    public WebElement docIsSignedBtn;

    @FindBy(xpath = "//label[text()= 'Office']/parent::div//input")
    public WebElement officeField;

    @FindBy(xpath = "//table[@data-role='grid']//tr/td[3]")
    public List<WebElement> officeGridFirstName;

    @FindBy(xpath = "//b[@data-testid=\"full_name\"]")
    public WebElement votersFullName;

    @FindBy(xpath = "//div[class='ProfileCard-realName']")
    public WebElement votersProfileCard;

    @FindBy(xpath = "//div[./span[text()='Status Reason']]/following-sibling::div")
    public WebElement voterStatusReason;

    @FindBy(xpath = "//div[@data-testid='residential_address']//div[normalize-space()='Confidential']")
    public WebElement residentialAddressConfidentialFlag;

    @FindBy(xpath = "//div[@data-testid='mailing_address']//div[normalize-space()='Confidential']")
    public WebElement mailingAddressConfidentialFlag;

    @FindBy(xpath = "//div[@data-testid='residential_address']//div[normalize-space()='Court Ordered']")
    public WebElement residentialAddressSecureFlag;

    @FindBy(xpath = "//div[@data-testid='mailing_address']//div[normalize-space()='Court Ordered']")
    public WebElement mailingAddressSecureFlag;

    @FindBy(css = "#incomplete_reason_multiselect")
    public WebElement incompleteReasonMultiselectDrp;

    @FindBy(xpath = "//div[./span[text()='Flags']]/following-sibling::div")
    public WebElement voterFlags;

    @FindBy(xpath = "//i[@class='fas fa-pencil-alt']")
    public WebElement editSignature;

    @FindBy(xpath = "//img[@data-testid='signature']")
    public WebElement signaturePNG;

    @FindBy(xpath = "//*[(text() = 'DMV')]")
    public WebElement signatureFormType;

    @FindBy(xpath = "//button[@data-testid='save' and not(@disabled)]")
    public WebElement clickSignSavebutton;

    @FindBy(id = "Address")
    public WebElement mailingLabelRegistrantMailingAddress;

    @FindBy(id = "CityStZip")
    public WebElement mailingLabelMailingCityZipInp;

    @FindBy(xpath = "//a[@data-testid=\"print_custom_label\"]")
    public WebElement printCustomLabel;

    @FindBy(id = "PartySinceDate")
    public WebElement partySinceDate;

    @FindBy(xpath = "//input[@data-testid='application_date']")
    public WebElement applicationDate;
    @FindBy(xpath = "//button[@id='print']")
    public WebElement printBttn;

    @FindBy(xpath = "//embed")
    public WebElement downldScreen;

    @FindBy(xpath = "//div[./span[text()='Status Reason']]/following-sibling::div")
    public WebElement statusReason;

    @FindBy(id = "RegistrationDate")
    public WebElement eligibilityDate;

    @FindBy(xpath = "//*[contains(text(),'Under 18')]")
    public WebElement hdrUnderEighteen;

    @FindBy(xpath = "//*[contains(text(),'age of this registrant is less than 18 years old')]")
    public WebElement msgUnderEighteen;

    @FindBy(xpath = "//label[normalize-space()='Address']/following-sibling::div//input[@id='quickSearch']")
    public WebElement inpAddressQuickSearch;

    @FindBy(xpath = "//select[@data-testid='change_type']")
    public WebElement drpChangeType;

    public void selectNoticeNameAndAddComments(String noticeType, String comments) {
        nativeDropdownSelect(drpNoticeName, noticeType);
        inpNotesComments.sendKeys(comments);
        btnInsert.click();
    }

    public void verifyCorrespondenceTitleCreated(String type) {
        WebElement element = getElementByText(type);
        Assert.assertTrue(element.isDisplayed());
        By loc = By.xpath("//td[text()='" + type + "']/following-sibling::td[@data-testid=\"NoticeID\"]");
        Helper.NOTICE_ID = driver.findElement(loc).getText().trim();

    }

    public void enterIntoQuickSearchField(String text) {
        inpQuickSearch.sendKeys(text);
        By voterSearchResult = By.xpath("//div[@data-testid='quick_search_results']//div[normalize-space()='" + text + "']");
        waitUntilElementToBePresent(voterSearchResult, 5).click();
        waitForSpinner();
    }

    public void userClickOnAddRegistrantButton() {
        addButton.click();
    }

    public void deleteCorrespondenceNotice() {
        if (!isElementPresent(noticeDeleteBtn)) {
            return;
        }
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", noticeDeleteBtn);
        noticeDeleteBtn.click();
        noticeConfirmDeleteBtn.click();
        noticeConfirmOKBtn.click();
        waitForSpinner();
        Assert.assertEquals(noticeDeleteButton.size(), 0);
    }

    public void updateAddressField(String addressField) {
        waitForSpinner();
        addressInp.click();
        addressInp.clear();
        addressInp.sendKeys(addressField);

    }

    public void updateCityField(String cityField) {
        cityInp.click();
        cityInp.clear();
        waitForSpinner();
        cityInp.sendKeys(cityField);
    }

    public void updateZipField(String zipField) {
        zipInp.click();
        zipInp.clear();
        waitForSpinner();
        zipInp.sendKeys(zipField);
        //waitForSpinner();
    }

    public void verifyResidentialAddress() {
        String resAddress = addressResidential.getText().replace("\n", " ").toUpperCase();
        Assert.assertEquals(resAddress, COMPLETE_ADDRESS);
    }

    public void verifyMailingAddress() {
        String resAddress = addressResidential.getText().replace("\n", "");
        Assert.assertEquals(resAddress, COMPLETE_ADDRESS);
    }

    public void clickUpdateAddressBtn() {
        waitForSpinner();
        updateAddressBtn.click();
    }

    public void selectFormTypeDropDown(String text) {
        WebElement input = driver.findElement(By.xpath("//div[@role='document' and .//h5[text()='Scan Document']]//label[normalize-space()= 'Form Type']//following-sibling::*[contains(@class,'dropdown')]//button"));
        clickElementByJS(input);
        sleep(2);
        isPresentAndDisplayed(driver.findElement(By.xpath("//li[@role='option']//*[normalize-space()='" + text + "']")));
        WebElement loctext = driver.findElement(By.xpath("//li[@role='option']//*[normalize-space()='" + text + "']"));
        clickElementByJS(loctext);
        sleep(2);
    }

    public void verifyScanFormWasCreated(String type) {
        WebElement element = getElementByText(type);
        Assert.assertTrue(element.isDisplayed());

    }

    public void verfiesNoticesDisplayedInTheQueue(String noticeName) {
        By loc = By.xpath("//*[@id=\"taskQueueContainer\"]//a[text()='" + noticeName + "']");
        scrollToElement(driver.findElement(loc));
        clickElementByJS(driver.findElement(loc));
        Assert.assertEquals(getElementByText(Helper.NOTICE_ID).getText(), Helper.NOTICE_ID);
    }

    public void enterIntoNoteField(String text) {
        if (isElementPresent(requiredNoteMessage)) {
            noteBtn.click();
            inputNote.clear();
            inputNote.sendKeys(text);
            waitForSpinner();
        } else {

        }
    }

    public void setBarcode(String barcode) {
        waitForSpinner();
        barcodeField.sendKeys(barcode);
        barcodeField.sendKeys(Keys.ENTER);
        waitForSpinner();

    }

    public void getReportCount(String reportCount) {
        waitForSpinner();
        By xpath = By.xpath("//a[text()='" + reportCount + "']/parent::*//span[contains(@class,'rounded-pill')]");
        Helper.OUT_OF_COUNTY_MATCHES_REPORT_COUNT = driver.findElement(xpath).getText();
    }

    public void getCountyMatchesReportAndVerifyWithTaskQueue() {
        Integer cnt = Integer.parseInt(outOfCountyMatchesReportCount.get(0).getText()) * 2;
        Assert.assertEquals(cnt, Integer.parseInt(Helper.OUT_OF_COUNTY_MATCHES_REPORT_COUNT));
        testLogger.info("Actual Count is:" + cnt + " Expected Count is:" + Helper.OUT_OF_COUNTY_MATCHES_REPORT_COUNT);
    }

    public void verifyRegistrationInformation(List<String> data) {
        String label = data.get(0);
        String value = data.get(1);
        By labelText = By.xpath("//div[./span[text()='" + label + "']]/following-sibling::div");
        String actualValue = driver.findElement(labelText).getText().trim();
        Assert.assertEquals(actualValue, value);
    }

    public void verifyVoterInformation(List<String> data) {
        String label = data.get(0);
        String value = data.get(1);
        By labelText = By.xpath("//div[./span[text()='" + label + "']]/following-sibling::div");
        String actualValue = driver.findElement(labelText).getText().trim();
        Assert.assertEquals(actualValue, value);

    }

    public void verifyVoterDocIsSigned() {
        docIsSignedBtn.click();

    }

    public void verifyTextInCapitalLetters(String field) {
        By fieldText = By.xpath("//label[contains(text(),'" + field + "')]/following-sibling::input");
        String actualValue = driver.findElement(fieldText).getAttribute("value");
        Assert.assertEquals(actualValue, actualValue.toUpperCase());
    }

    public void enterOfficeName(String officeName) {
        this.officeName = officeName;
        officeField.sendKeys(officeName);
    }


    public void UserVerifyYouCanSearchForTheVoterInQuickSearch() {
        waitForSpinner();
        inpQuickSearch.sendKeys(Helper.getLastNameFirstName());
        By voterSearchResult = By.xpath("//div[@data-testid='quick_search_results']//div[normalize-space()='" + Helper.getLastNameFirstName() + "']");
        waitUntilElementToBePresent(voterSearchResult, 20).click();
        driver.findElement(voterSearchResult).click();
        waitForSpinner();
    }

    public void userVerifyYouAreUnableToSearchForVoterInQuickSearch() {
        waitForSpinner();
        inpQuickSearch.sendKeys(Helper.getLastNameFirstName());
        By voterSearchResult = By.xpath("//div[@data-testid='quick_search_results']//div[normalize-space()='" + Helper.getLastNameFirstName() + "']");
        boolean voterProfile = checkIfElementIsVisible(voterSearchResult, 8);
        Assert.assertFalse(voterProfile, "Voter name is not displayed");
    }

    public void userVerifiesResidentialAndMailingAddressHasConfidentialFlags() {
        Assert.assertTrue(residentialAddressConfidentialFlag.isDisplayed());
        Assert.assertTrue(mailingAddressConfidentialFlag.isDisplayed());
    }

    public void userVerifiesResidentialAndMailingAddressHasSecureFlags() {
        Assert.assertTrue(residentialAddressSecureFlag.isDisplayed());
        Assert.assertTrue(mailingAddressSecureFlag.isDisplayed());
    }

    public void userSelectFromIncompleteReason(String reason) {
        incompleteReasonMultiselectDrp.sendKeys(reason);
        incompleteReasonMultiselectDrp.sendKeys(Keys.ENTER);
        waitForSpinner();

    }

    public void userClicksOnToggleOn(String option) {
        By toggleOn = By.xpath("//label[text()='" + option + "']/preceding-sibling::span//span[text()='Off']");
        By toggleStatus = By.xpath("//label[text()='" + option + "']/preceding-sibling::span//input");

        String status = driver.findElement(toggleStatus).getAttribute("value");
        if (status.equals("false")) {
            driver.findElement(toggleOn).click();
        }
    }

    public void verifyActivitiesTabWithinARegistrant() {
        waitForSpinner();
        Assert.assertTrue(getElementByText("Activity").isDisplayed());
    }

    public void userClickOnEditSignature() {
        editSignature.click();
        waitForSpinner();
    }

    public void userVerifiesSignatureDisplayingUnderVotersName() {
        Assert.assertTrue(signaturePNG.isDisplayed());
    }

    public void selectFormTypeSignature(String option) {
        htmlDropdownSelect(signatureFormType, option);
    }

    public void userClickOnSaveButton() {
        clickSignSavebutton.click();
    }

    public void VerifyVotingHistoryTabHasNoRecords() {
        waitForSpinner();
        Assert.assertTrue(getElementByText("No Records").isDisplayed());
    }

    public void verifyMailingLabelResidentialAddress() {
        String address = mailingLabelRegistrantMailingAddress.getAttribute("value").trim();
        String addressCityZIp = mailingLabelMailingCityZipInp.getAttribute("value").replace(",", "").trim();
        String mailingLabelResidentialAddress = String.format("%s %s", address, addressCityZIp);
        Assert.assertEquals(mailingLabelResidentialAddress, COMPLETE_ADDRESS);
    }

    public void userVerifyTheValuesFromDropDown(String dropdownLabel, List<String> expectedValues) {
        By dropLoc = By.xpath("//label[normalize-space()='" + dropdownLabel + "']/following-sibling::select");
        List<String> actualValues = getSelectOptions(driver.findElement(dropLoc));
        actualValues.remove("");
        boolean containsAllExpectedValues = actualValues.containsAll(expectedValues);
        Assert.assertTrue(containsAllExpectedValues, "Dropdown values are verified for the dropdown selected: " + dropdownLabel);
    }

    public void userVerifiesCurrentDateIsDisplayedForPartySinceDate() {
        String actualPartySinceDate = partySinceDate.getAttribute("value");
        String currentDate = getDateInFormat("yyyy-MM-dd", 0);
        Assert.assertEquals(actualPartySinceDate, currentDate);
    }

    public void userEntersDateThatIsDaysPriorFromCurrentDateForApplicationDate(int days) {
        String pastDate = getDateInFormatMinusDays("MM/dd/yyyy", days);
        applicationDate.click();
        applicationDate.clear();
        applicationDate.sendKeys(pastDate);
    }

    public void userClickOnPrintButton() {
        printBttn.click();
        waitForSpinner();
    }

    public void userVerifyDownloadScreen() {
        waitForSpinner();
        Assert.assertTrue(downldScreen.isDisplayed());
    }

    public String getVisibleRecordCount() {
        return outOfCountyMatchesReportCount.stream().filter(X -> X.isDisplayed() == true).findFirst()
                .orElseThrow(() -> new AssertionError("Not found")).getText();
    }

    public void entersDOBForVoter(int days, int years) {
        String dob = getDateInFormatPlusMinus("MM/dd/yyyy", years, days);
        WebElement input = driver.findElement(By.xpath("//label[contains(text(), 'Date Of Birth')]/following-sibling::*"));
        input.click();
        input.clear();
        input.sendKeys(dob + Keys.TAB);
    }

    public void verifyEligibilityDateDisplaysDateVoterTurn18() {
        String actualEligibilityDate = eligibilityDate.getAttribute("value");
        String dateVoterTurn18 = getDateInFormat("yyyy-MM-dd", 1);
        Assert.assertEquals(actualEligibilityDate, dateVoterTurn18);
    }

    public void verifyUnderEighteenAlertDisplayed() {
        Assert.assertTrue(hdrUnderEighteen.isDisplayed());
        Assert.assertTrue(msgUnderEighteen.isDisplayed());
    }

    public void verifySearchResultsAreDisplaying() {
        try {
            String text = searchResultCount.getText();
            int count = Integer.parseInt(text);
            Assert.assertTrue(count > 0, "Search results count is : " + count);
        } catch (NoSuchElementException e) {
            Assert.fail("Search result 'No Results Found' ");
        }
    }

    public void enterAddress(String address) {
        inpAddressQuickSearch.sendKeys(address);
        String xpath = String.format("//div[@data-testid='result_name' and text()='%s']",address);
        waitForVisibilityOfElement(By.xpath(xpath),10).click();
        sleep(4);

    }

    public void selectChangeType(String label) {
        nativeDropdownSelect(drpChangeType,label);
    }
}

