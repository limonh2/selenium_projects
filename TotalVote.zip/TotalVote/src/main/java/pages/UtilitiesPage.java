package pages;


import net.bytebuddy.implementation.bytecode.Throw;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import utils.Base;
import utils.DriverFactory;
import utils.Helper;
import java.util.Random;
import java.util.List;

import static utils.Helper.*;


public class UtilitiesPage extends Base {

    JavascriptExecutor js = ((JavascriptExecutor) DriverFactory.getDriver());

    public UtilitiesPage() {
        PageFactory.initElements(DriverFactory.getDriver(), this);
    }

    @FindBy(xpath = "//div[@style='display: block;']//select[@id='notice-template-select']")
    public WebElement drpNoticeName;

    @FindBy(xpath = "//input[@value=\"Save\"]")
    public WebElement saveBtnNotice;
    @FindBy(xpath = "//td[contains(@class, 'k-state-selected')]")
    public WebElement currentDate;

    @FindBy(xpath = "//input[@id='rcbCounty']")
    public WebElement countyListBox;

    @FindBy(xpath = "//input[@id='Apache']")
    public WebElement countyListBoxOption;

    //input[@id=\"Apache\"]"

    @FindBy(xpath = "//label[text()=' Petition Title: ']/following-sibling::input")
    public WebElement petitionTitleBox;

    @FindBy(xpath = "//table[@class ='w-100 table table-striped table-hover']")
    public List <WebElement> petitionList;


    public void verifyValuePresentInDropDown(String noticeType) {
        nativeDropdownSelect(drpNoticeName, noticeType);
        Assert.assertTrue(isNativeDropdownSelected(drpNoticeName, noticeType));
    }

    public void clickSaveBtnNoticeMgmt() {
        saveBtnNotice.click();
        waitForSpinner();
    }

    public void selectRandomValuesFromDropdown(String dropdownText) {
        // Create the dynamic locator based on the provided text
        By dynamicLocator = By.xpath("//label[text()='" + dropdownText + "']/following-sibling::select[@class='form-control p-2']");

        // Find the dropdown element using the dynamic locator
        WebElement dropdownElement = driver.findElement(dynamicLocator);

        // Use the Select class to work with the dropdown
        Select dropdown = new Select(dropdownElement);
        List<WebElement> options = dropdown.getOptions();

        if (options.size() > 1) {

            int randomIndex = new Random().nextInt(options.size() - 1) + 1;
            dropdown.selectByIndex(randomIndex);

        } else if (options.size() == 1) {
            dropdown.selectByIndex(0);
        } else {
            throw new RuntimeException("Dropdown has no options to select");
        }
    }

    public void selectCurrentDateFromCalendar(List<String> fieldNames) {
        for (String fieldName : fieldNames) {
            By dynamicLocator = By.xpath("//div[@class='col-lg-4 col-sm-12']/label[contains(text(), '" + fieldName + "')]/following-sibling::*/button");
            WebElement element = driver.findElement(dynamicLocator);
            element.click();
            clickCurrentCalendarDate();
        }
    }

    public void clickCurrentCalendarDate() {
        currentDate.click();
        waitForSpinner();
    }

    public void enterCountiesText(String countListBox) {
        waitForSpinner();
        countyListBox.sendKeys(countListBox, Keys.ENTER);
    }

    public void clickCountyListBox() {
        //waitForSpinner();
        hoverClick(countyListBoxOption, countyListBox);
    }

    public void verifyPetitionIsAddedToThePetitionList() {
        String title = Helper.getPetitionTitle();
        WebElement petitionTitle = driver.findElement(By.xpath("//*[contains(text(),'" + title + "')]"));
        Assert.assertTrue(petitionTitle.isDisplayed(), "Petition not found");
    }

    public void enterRandomDescriptionforPetitionTitle() {
        petitionTitleBox.click();
        petitionTitleBox.clear();
        String title = getRandomString(6);
        Helper.setPetitionTitle(title);
        petitionTitleBox.sendKeys(title);
    }

    public void enterRandomText(String field) {
        String input;
        WebElement inputField = driver.findElement(By.xpath("//label[text()='" + field + "']/following-sibling::input"));

        if (field.equals("District Number")) {
            input = getRandomNumber(3);
            inputField.sendKeys(input);
        }
        else if(field.equals("District Description"))
        {
            input = getRandomString(6);
            inputField.sendKeys(input);
        }

        else if(field.equals("District Name")){
            input = getRandomString(6);
            Helper.setDistrictName(input);
            inputField.sendKeys(input);
        }
        else {
            throw new RuntimeException("There is no match");
        }

    }
    public void verifyDistrictIsAddedToTheDistrcitList() {
        String title = Helper.getDistrictName();
        WebElement districtName = driver.findElement(By.xpath("//td[text()='" + title + "'"));
        Assert.assertTrue(districtName.isDisplayed(), "District not found");
    }

    public void getElementByValue(String value) {
        driver.findElement(By.cssSelector("input[type='button'][value='" + value + "']")).click();
        waitForSpinner();
    }

    public void verifyNoticeCopiedSuccessfully(){
        Select select = new Select(driver.findElement(By.id("ddlTemplates")));
        String expectedValue = "Automation Test Copy";

        List<WebElement> options = select.getOptions();
        boolean found = false;

        for(WebElement option : options) {
            if(option.getText().equals(expectedValue)) {
                found = true;
                break;
            }
        }
        Assert.assertTrue(found, "Notice was not successfully copied");
    }

    public void verifyNoticeNotDisplayedInDropdown(){
        Select select = new Select(driver.findElement(By.id("ddlTemplates")));
        String expectedValue = "Automation Test Copy";

        List<WebElement> options = select.getOptions();
        boolean found = false;

        for(WebElement option : options) {
            if(option.getText().equals(expectedValue)) {
                found = true;
                break;
            }
        }
        Assert.assertFalse(found, "Notice was found when it should not have been");
    }
}



