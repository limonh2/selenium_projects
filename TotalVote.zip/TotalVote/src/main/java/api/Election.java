package api;

import okhttp3.*;

import java.io.IOException;

public class Election {
    // GET Election
    public void getElection() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/election/getelection?electionId=100004962")
                .method("GET", body)
                .addHeader("electionId", "")
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void postNewElection() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n    \"elCountyId\": 1,\r\n    \"elNameAbbr\": \"ELEPOST\",\r\n    \"elAbsenteeClosed\": \"2024-06-27\",\r\n    \"elAllMail\": false,\r\n    \"elAllowPostingPartyInfo\": false,\r\n    \"elDescription\": \"Making a simple election POSTMAN\",\r\n    \"elTimeStamp\": \"2024-02-22T18:21:53.333\",\r\n    \"elemId\": 316,\r\n    \"elRegistrationClosed\": \"2024-06-11\",\r\n    \"calcTypeDate\": \"MUNICIPAL July 01, 2024\",\r\n    \"elUOCAVADate\": \"2024-05-18\",\r\n    \"coCountyName\": \"Apache\",\r\n    \"elOutOfStateDate\": \"2024-06-27\",\r\n    \"elFirstInStateDate\": \"2024-06-14\",\r\n    \"elLastInStateDate\": \"2024-06-12\",\r\n    \"elNoDailyMailServiceDate\": \"2024-06-18\",\r\n    \"elAbsenteeOrReplacementDate\": \"2024-06-03\",\r\n    \"elCloseOfCanvass\": \"2024-05-18\",\r\n    \"elRequestAMailBallotDate\": \"2024-06-27\",\r\n    \"elLastUOCAVADate\": \"2024-06-27\",\r\n    \"electionName\": \"2024 MUNICIPAL\",\r\n    \"electionDate\": \"2024-07-01\",\r\n    \"electionType\": \"MUNICIPAL\",\r\n    \"epActive\": false,\r\n    \"elPostProcessingDate\": \"2024-05-18\",\r\n    \"elLockoutDate\": \"2024-05-18\"\r\n}");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/election/add")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
