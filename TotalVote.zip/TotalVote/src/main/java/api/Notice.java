package api;

import okhttp3.*;

import java.io.IOException;

public class Notice {

    public void getActiveNoticeTemplate() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/noticemanagement/noticetemplategetactive?countyId=1&userId=316")
                .method("GET", body)
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void postNewNoticeTemplate() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n    \"name\": \"Notice Simple 123\",\r\n    \"description\": \"Test API\",\r\n    \n    \"userId\": 316,\r\n    \"canBeEmailed\": true,\r\n    \"noticeTemplateSizeId\": 1,\r\n    \"isEmailOnly\": false,\r\n    \"isSMSOnly\": false,\r\n    \"pageMarginTopInches\": 0,\r\n    \"pageMarginBottomInches\": 0,\r\n    \"pageMarginLeftInches\": 0,\r\n    \"pageMarginRightInches\": 0,\r\n    \"horizontalSpaceBetweenNoticesInches\": 0,\r\n    \"verticalSpaceBetweenNoticesInches\": 0,\r\n    \"countyCanEdit\": true,\r\n    \"countyOptOut\": true,\r\n    \"countyId\": 1\r\n}");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/noticemanagement/noticetemplatecountyinsert")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
