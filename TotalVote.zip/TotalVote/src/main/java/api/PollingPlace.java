package api;

import okhttp3.*;

import java.io.IOException;

public class PollingPlace {

    public void getPollingPlace() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/pollingplace/getbyid?id=100001586")
                .method("GET", body)
                .addHeader("API-KEY", "54F0CA11-6986-4AC7-A580-8A42D3E3657B")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void getPollingPlaceByCounty() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/pollingplace/pollingplacespagedbycountycode?statuses=ACTIVE&countyCode=1&search=Fire")
                .method("GET", body)
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public void postNewPollingPlace() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n    \"countyId\": 1,\r\n    \"placeName\": \"Fire Department POST\",\r\n    \"placeTypeLookupId\": 1540,\r\n    \"placeAddress\": \"17 County Road 2067\",\r\n    \"placeCity\": \"Alpine\",\r\n    \"placeState\": \"AZ\",\r\n    \"status\": \"active\",\r\n    \"isVoteCenter\": false,\r\n    \"placeZip\": \"85920\",\r\n    \"placeDescription\": \"Polling Place Fire \",\r\n    \"emId\": 316,\r\n    \"timestamp\": \"2024-02-13\",\r\n    \"pollingPlaceContacts\": [],\r\n    \"pollingPlaceDateTime\": [],\r\n    \"pollingPlaceProperties\": [\r\n        {\r\n            \"type\": \"earlyVoteSite\",\r\n            \"notes\": \"\",\r\n            \"enabled\": true\r\n        },\r\n        {\r\n            \"type\": \"collectionSite\",\r\n            \"notes\": \"\",\r\n            \"enabled\": true\r\n        },\r\n        {\r\n            \"type\": \"firearmsProhibited\",\r\n            \"notes\": \"\",\r\n            \"enabled\": true\r\n        }\r\n    ],\r\n    \"isEarlyVoteSite\": false,\r\n    \"isCollectionSite\": true,\r\n    \"isDropBox\": false,\r\n    \"isIssuesBallot\": false\r\n}");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/pollingplace/addpollingplace")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
