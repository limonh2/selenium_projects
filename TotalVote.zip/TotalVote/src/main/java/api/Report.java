package api;

import okhttp3.*;

import java.io.IOException;

public class Report {
    public void getReport() {

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/reportbuilder/getreports")
                .method("GET", body)
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void postNewReport() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n    \"name\": \"Report API candidate proofing\",\r\n    \"json\": \"{\\\"TypeFromEntity\\\":\\\"TotalVote.DAL.Models.CustomEntities.VwRptCandidateProofing, TotalVote.DAL, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null\\\",\\\"LastRun\\\":null,\\\"Name\\\":\\\"Report API candidate proofing\\\",\\\"WhereClause\\\":null,\\\"Entity\\\":{\\\"Id\\\":20,\\\"Entity\\\":\\\"Candidate Proofing\\\",\\\"Description\\\":\\\"Includes Candidate Proofing Data\\\",\\\"Group\\\":\\\"Election Setup\\\"},\\\"Description\\\":\\\"Description API report\\\",\\\"SelectedFields\\\":[\\\"ElectionID\\\",\\\"ElectionName\\\",\\\"ElectionType\\\",\\\"ElectionDate\\\",\\\"OfficeSeqNum\\\",\\\"FilingOffice\\\",\\\"BallotOrder\\\",\\\"FirstName\\\",\\\"LastName\\\",\\\"MiddleName\\\",\\\"Suffix\\\",\\\"BallotName\\\",\\\"OfficeSought\\\",\\\"ResidentialAddress\\\",\\\"City\\\",\\\"State\\\",\\\"Zip\\\",\\\"MailingAddress\\\",\\\"MailingCity\\\",\\\"MailingState\\\",\\\"MailingZip\\\",\\\"Phone\\\",\\\"EmailAddress\\\",\\\"Party\\\",\\\"IsPrimary\\\",\\\"Notes\\\",\\\"Confidential\\\",\\\"Status\\\"],\\\"Filters\\\":[],\\\"SharedReport\\\":false,\\\"GridColumnStates\\\":[]}\",\r\n    \"createdDate\": \"2024-02-23\",\r\n    \"createdBy\": 316,\r\n    \"shared\": false,\r\n    \"deleted\": false,\r\n    \"description\": \"Description API report\"\r\n}");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/reportbuilder/createreport")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
