package api;

import okhttp3.*;
import org.testng.annotations.Test;

import java.io.IOException;

public class Voter {

    public void getVoter() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/voter?voterId=10123800&includeDistricts=false&includeSignature=false")
                .method("GET", body)
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void postNewVoter() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n    \"firstName\": \"SDSDSDPOST\",\r\n    \"lastName\": \"TYLER\",\r\n    \"middleName\": \"H\",\r\n    \"dob\": \"1970-01-01\",\r\n    \"ssN4\": \"2134\",\r\n    \"ssN4Verified\": false,\r\n    \"dl\": \"79579342\",\r\n    \"dlVerified\": false,\r\n    \"isUSCitizen\": true,\r\n    \"isPEVL\": false,\r\n    \"isUOCAVA\": false,\r\n    \"isAgent\": false,\r\n    \"isHomePhoneMobile\": false,\r\n    \"isAlternatePhoneMobile\": false,\r\n    \"isDocumentSigned\": false,\r\n    \"isEarlyVoter\": false,\r\n    \"countyCode\": 1,\r\n    \"countyName\": \"Apache\",\r\n    \"communicationEmailOptOut\": false,\r\n    \"communicationSMSOptOut\": false,\r\n    \"subscribleEmail\": false,\r\n    \"subscribeSSMS\": false,\r\n    \"registrationDate\": \"2024-02-22T00:00:00\",\r\n    \"effectiveDateOfReg\": \"2024-02-22T00:00:00\",\r\n    \"originalRegistrationDate\": \"2024-02-22T00:00:00\",\r\n    \"applicationDate\": \"1987-01-01T00:00:00\",\r\n    \"sourceOfRegistration\": \"Online\",\r\n    \"howRegistered\": \"Electronic\",\r\n    \"formLanguage\": \"English\",\r\n    \"registrationStatus\": \"ACTIVE\",\r\n    \"registrationStatusReason\": \"ACTIVE\",\r\n    \"registrationStatusID\": 1,\r\n    \"registrationStatusReasonID\": 1,\r\n    \n    \"idRequired\": false,\r\n    \"selfIdentifiedCitizen\": false,\r\n    \"modifiedEmployeeID\": 316,\r\n    \"selfIdentifiedCitizenText\": \"No\",\r\n    \"isUSCitizenText\": \"Yes\",\r\n    \"incompleteReasonsParsed\": [],\r\n    \"bilingualLanguagesParsed\": [],\r\n    \"isNVRA\": false,\r\n    \"isCountyEdit\": false,\r\n    \n    \"otherParty\": \"\",\r\n    \n    \n    \"deathID\": 0,\r\n    \"felonyID\": 0,\r\n    \"imageID\": 0,\r\n    \n    \"totalAddressId\": 2732947,\r\n    \"precinctPart\": \"01008601\",\r\n    \"precinctPartID\": 31348,\r\n    \"precinctNumber\": \"010113\",\r\n    \"precinctSplit\": \"86.1 SD 18 FD 18\",\r\n    \"districts\": [],\r\n    \"residentialAddress\": {\r\n        \"addressType\": 1,\r\n        \"address1\": \"123 MAIN STREET\",\r\n        \"city\": \"ALPINE\",\r\n        \"zip\": \"86502\",\r\n        \"state\": \"AZ\",\r\n        \"isNonStandard\": false,\r\n        \"isCommercial\": false,\r\n        \"isStateWideSearch\": false,\r\n        \"isForeign\": false,\r\n        \"totalAddressId\": \"2732947\",\r\n        \"addressCombined\": \"123 MAIN STREET, ALPINE, AZ, 86502\",\r\n        \"isRecurring\": false,\r\n        \"houseNumber\": \"123\",\r\n        \"streetName\": \"MAIN STREET\",\r\n        \"selectedAddressCounty\": 0,\r\n        \"verifiedExternal\": true\r\n    },\r\n    \"olvrId\": 0,\r\n    \"dolId\": 0,\r\n    \"hasNameChanged\": false,\r\n    \"pollworker\": false,\r\n    \"pollworkerInterest\": false,\r\n    \"electionBallotInterest\": false,\r\n    \"bilingualInterest\": false,\r\n    \"suppressionLvl\": 3,\r\n    \"hallOfFame\": false,\r\n    \"federalOnly\": false,\r\n    \"flags\": [\r\n        {\r\n            \"displayName\": \"HAVA ID Required\",\r\n            \"type\": \"Warning\"\r\n        }\r\n    ],\r\n    \"mergedDuplicateRecords\": [],\r\n    \"optOutFuturePreference\": false,\r\n    \"optInFuturePrimaryPreference\": false,\r\n    \"optInFutureGeneralPreference\": false,\r\n    \"optInFutureSpecialPreference\": false,\r\n    \"isOptOutVBM\": false,\r\n    \"optOutAddressPreference\": 0,\r\n    \"sysStartTime\": \"2024-02-22T20:53:49.7908856\",\r\n    \"ethnicity\": \"\",\r\n    \"tprId\": 0,\r\n    \"showPrivilegeDate\": false\r\n}");
        Request request = new Request.Builder()
                .url("https://core-test-totalvoteapi.azurewebsites.us/api/voter/createnew")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("API-KEY", "API-KEY")
                .build();
        try {
            Response response = client.newCall(request).execute();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}