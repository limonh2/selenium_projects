package feature.NVRegression;

import io.cucumber.testng.CucumberOptions;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import runner.AbstractTestNGCucumberParallelTests;
import runner.GenerateHtmlReport;

@CucumberOptions(
        features = "src/test/java/feature/",
        glue = {"stepDefs", "utils"},
        tags = "@NVSTGRegression and not @bug and not @ignore",
        dryRun = false,
        plugin = {"json:target/reports/cucumber.json",
                "html:target/reports/index.html",
                "rerun:target/failed_testscenarios.txt",
                "pretty", "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"})

public class NVTestRunner extends AbstractTestNGCucumberParallelTests {
    @BeforeTest
    public void threadCount(ITestContext context) {
        context.getCurrentXmlTest().getSuite().setDataProviderThreadCount(6);
        context.getCurrentXmlTest().getSuite().setPreserveOrder(false);
    }

    @AfterSuite
    public void report() {
        GenerateHtmlReport.main(new String[1]);
    }
}