package stepDefs;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import pages.HomePage;
import pages.ReportPage;
import utils.Helper;
import utils.SharedDriver;


public class ReportSteps {


    public ReportPage reportPage;
    public HomePage homePage;

    int reportbuilderReport_count = 0;

    public ReportSteps(SharedDriver driver, ReportPage reportPage) {
        this.reportPage = reportPage;
    }

    @Then("User verify the {string} report was generated")
    public void userVerifyTheReportWasGenerated(String reportName) {
        reportPage.getElementByLinkText(reportName).click();
        reportPage.waitForSpinner();
        By report = By.xpath("//div[normalize-space()='" + reportName + "']");
        reportPage.isElementVisible(report);
    }

    @And("User select the checkbox {string} from Reports")
    public void userCheckTheReportFromReports(String reportName) {
        reportPage.getElementByText(reportName).click();
        reportPage.waitForSpinner();
        By report = By.xpath("//td[normalize-space()='" + reportName + "']");
        reportPage.isElementVisible(report);

    }


    @And("User enters {string} into Report Name field")
    public void userEntersIntoReportNameField(String reportName) {
        String report = Helper.getReportName();
        if (reportName.contains("randomtext")) {
            String textToReplace = Helper.getRandomString(6);
            report = reportName.replaceAll("randomtext", textToReplace);
            Helper.setReportName(report);
        }
        reportPage.userEntersReportName(report);

    }

    @And("User enters {string} into Report Description field")
    public void userEntersIntoReportDescriptionField(String reportDescription) {
        if (reportDescription.contains("randomtext")) {
            String textToReplace = Helper.getRandomString(6);
            reportDescription = reportDescription.replaceAll("randomtext", textToReplace);
        }
        reportPage.userEntersReportDescription(reportDescription);
    }


    @And("User verify Report Name and click on Run button")
    public void userVerifyReportNameAndClickOnRunButton() {
        reportPage.clickOnReportRunButton();
    }


    @And("I download the report")
    public void iDownloadTheReport() {
        reportPage.downloadReport();
        reportPage.waitForSpinner();
    }

    @Then("I validate the file was downloaded")
    public void iValidateTheFileWasDownloaded() {
        reportPage.waitForSpinner();
        reportPage.validateFileIsDownloaded();
    }

    @And("User click on Next on Add Report page")
    public void userClickOnNextOnAddReportPage() {
        reportPage.userClickOnNextOnAddReportPage();
    }

    @And("User selects {string} from Other Options")
    public void userSelectsStringFromOtherOptions(String options) {
        WebElement checkboxOption = reportPage.driver.findElement(By.xpath("//input[@type='checkbox']/following-sibling::span[text()='" + options + "']"));
        reportPage.waitAndClick(checkboxOption);
    }

    @And("User clicks a voter ID")
    public void userClicksVoterID(){
        reportPage.voterID();
    }

    @And("User enters date from {int} years ago registrationEndDate")
    public void userEntersDateFromYearsAgoEnd(int years) throws InterruptedException {
        //voterPage.userenters10yearagodate();
        reportPage.registrationDateEnd.sendKeys(reportPage.getDateInFormatPlusMinus("MM/dd/yyyy",years,0));
        Thread.sleep(4000);
    }

    @And("User enters date from {int} years ago into {string} field")
    public void userEntersDateFromYearsAgoo(int years, String field) throws InterruptedException {
        WebElement inputField = reportPage.driver.findElement(By.xpath("(//label[contains(text(), '" + field + "')]/following-sibling::*)[1]//input"));
        inputField.sendKeys(reportPage.getDateInFormatPlusMinus("MM/dd/yyyy", years, 0));
    }

    @Then("User verifies search results display in Advanced Search Report")
    public void userVerifiesSearchResultsDisplayInAdvancedReport() {
        reportPage.userVerifiesSearchResultsDisplaysInAdvancedSearchReport();
    }

    @And("User clicks on Expand button in Advanced Search")
    public void userClicksOnExpandButtonInAdvancedSearch() {
        reportPage.userClicksOnExpandButtonInAdvancedSearch();
    }

    @And("User click on Add button in Office Management")
    public void userClickOnAddButtonInOfficeMGT() {
        reportPage.clickOnAddButton();
    }
}


